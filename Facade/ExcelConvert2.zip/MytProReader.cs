using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Spire.Xls;

namespace HanchartDatabase
{
    public class MytProReader
    {
        private string _orgID;
        private string _filename;
        private DataTable excelDataTable;
        //private int _custcount = 0;
        public MytProReader(string orgID, string filename, int sheetNum)
        {
            _orgID = orgID;
            _filename = filename;
            Workbook workbook = new Workbook();

            workbook.LoadFromFile(_filename);

            //Initailize worksheet
            Worksheet sheet = workbook.Worksheets[sheetNum];
            excelDataTable = sheet.ExportDataTable();
        }
// MytPro Customer
        public List<CUSTOMERPERSONAL> ReadCustomer(int startRow, int size)
        {
            var customerList = new List<CUSTOMERPERSONAL>();
            int count = 0;
            //차트번호 성명 전화1 전화2 주민번호 생일 주소1 주소2 이메일 등록일 특이사항 VIP(고객 등급) SMS수신  내원경로																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																


            foreach (DataRow row in excelDataTable.Rows)
            {
                count++;
                if (count < startRow)
                    continue;

                //var r = row["중복여부"].ToString();
                //if (r != "0") continue;
                //차트번호 성명 전화1 전화2 주민번호 주소1 주소2 이메일 등록일 특이사항 VIP(고객 등급) SMS수신  내원경로 추천인 추천인차트번호

                var cust = new CUSTOMERPERSONAL();
                cust.ORGID = _orgID;

                cust.CUSTNO = row["차트번호"].ToString();
                cust.CUSTNAME = row["성명"].ToString();
                cust.CUSTCELL1 = row["전화1"].ToString();
                cust.CUSTCELL2 = row["전화2"].ToString();
                cust.CUSTJN = row["주민번호"].ToString();
                var dobType = row["양음력"].ToString();
                if(dobType == "양력")
                {
                    cust.DOBTYPE = "0";
                }
                else
                {
                    cust.DOBTYPE = "1";
                }
                var custdob = row["생일"].ToString();
                if (cust.CUSTJN != "" && cust.CUSTJN.Length > 6)
                {
                    if (custdob != "")
                        cust.CUSTDOB = cust.CUSTJN.Substring(0, 2) + custdob;
                    else
                        cust.CUSTDOB = cust.CUSTJN.Substring(0, 6);
                }
                else
                    cust.CUSTDOB = row["생일"].ToString();
                cust.CUSTADDR11 = row["주소1"].ToString();
                cust.CUSTADDR21 = row["주소2"].ToString();
                cust.CUSTEMAIL = row["이메일"].ToString();

                cust.CUSTREGDATE = row["등록일"].ToString().Replace("-", "");

                string custMemo = row["특이사항"].ToString();
                custMemo = System.Text.RegularExpressions.Regex.Replace(custMemo, @"<(.|\n)*?>", string.Empty);   //HTML 소스 제거
                cust.CUSTMEMO = custMemo;
                
                //var custlevel = row["VIP"].ToString();
                //if (custlevel == "N")
                //    cust.CUSTLVL = "일반";
                //else
                //    cust.CUSTLVL = "VIP";

                
                var smsCheck = row["SMS수신"].ToString();
                if (smsCheck == "Y")
                {
                    cust.RECVSMS = "1";
                }
                else if (smsCheck == "N")
                {
                    cust.RECVSMS = "2";
                }
                else
                {
                    cust.RECVSMS = "0";
                }


                //내원경로 - CUSTADDR22
                cust.CUSTINFX = row["내원경로"].ToString();

                cust.CUSTJOB = row["직업"].ToString();
                cust.CUSTFSTDATE = cust.CUSTREGDATE;
                //추천인 추천인차트번호
                cust.CUSTADDR31 = row["추천인"].ToString();
                cust.CUSTADDR32 = row["추천인차트번호"].ToString();

                cust.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
                customerList.Add(cust);

                if (customerList.Count() == size)
                    break;
            }

            return customerList;
        }
        // MytPro Schedule
        public List<CUSTOMERSCHEDULE> ReadResvSchedule(int startRow, int size)
        {
            var resvList = new List<CUSTOMERSCHEDULE>();
            int count = 0;

            foreach (DataRow row in excelDataTable.Rows)
            {
                count++;
                if (count < startRow)
                    continue;


                //MytPro//
                //예약
                var schedule = new CUSTOMERSCHEDULE();
                schedule.ORGID = _orgID;
                // static 
                schedule.SCHEDULESTATUS = "1";
                schedule.INSTYPE = "2";

                // excel
                schedule.CUSTNAME = row["고객"].ToString();
                schedule.CUSTNO = row["차트번호"].ToString();
                schedule.RESVMEMO = row["메모"].ToString();
                schedule.RESVDATE = row["예약일"].ToString().Replace("-", "");
                schedule.RESVTIME = row["시작"].ToString().Replace(":", "");
                if (schedule.RESVTIME.Length < 4)
                {
                    Console.WriteLine("Format_sttime :: " + schedule.RESVTIME);
                    schedule.RESVTIME = "0" + schedule.RESVTIME;
                    Console.WriteLine("CHANGE Format_sttime :: " + schedule.RESVTIME + "\n\n\n");
                }
                schedule.SCHDOCTOR = row["의사"].ToString();
                schedule.SCHNURSE = row["담당직원"].ToString();
                schedule.RESVEMPLID = row["예약확인자"].ToString();
                schedule.SVCAREA = row["진료분야 상"].ToString();
                schedule.SVCAREA2 = row["진료분야 하"].ToString();
                var cancel = row["취소"].ToString();
                if(cancel == "Y")
                {
                    schedule.SCHEDULESTATUS = "0";
                    schedule.RESVTIME = "0900";
                }
                var status = row["상태"].ToString();
                if(status == "방문")
                {
                    schedule.SCHEDULESTATUS = "7";
                    schedule.SCHEDULEDATE = schedule.RESVDATE;
                    schedule.SCHEDULETIME = schedule.RESVTIME;
                    schedule.CONSULTTIME = schedule.SCHEDULEDATE + schedule.SCHEDULETIME;
                }

                var nurseMemo = "";
                var tmpSvc = row["항목"].ToString();
                var svcArray = tmpSvc.Split(',');
                var svcarea = "";
                for(var i = 0; i < svcArray.Count(); i ++)
                {
                    if(svcarea != "")
                    {
                        svcarea += ", ";
                    }
                    if (svcArray[i] == "1")
                    {
                        svcarea += "초진";
                    }
                    if (svcArray[i] == "2")
                    {
                        svcarea += "상담";
                    }
                    if (svcArray[i] == "3")
                    {
                        svcarea += "시술";
                    }
                    if (svcArray[i] == "4")
                    {
                        svcarea += "경과";
                    }
                    if (svcArray[i] == "5")
                    {
                        svcarea += "치료";
                    }
                    if (svcArray[i] == "6")
                    {
                        svcarea += "토닝";
                    }
                    if (svcArray[i] == "11")
                    {
                        svcarea += "수술";
                    }
                    if (svcArray[i] == "12")
                    {
                        svcarea += "상담후시술";
                    }
                    if (svcArray[i] == "13")
                    {
                        svcarea += "상담후수술";
                    }
                    if (svcArray[i] == "14")
                    {
                        svcarea += "상담후관리";
                    }
                    if (svcArray[i] == "15")
                    {
                        svcarea += "바디관리";
                    }
                    if (svcArray[i] == "16")
                    {
                        svcarea += "재생레이져";
                    }
                    if (svcArray[i] == "17")
                    {
                        svcarea += "피부관리";
                    }
                    if (svcArray[i] == "18")
                    {
                        svcarea += "두피";
                    }
                }
                nurseMemo = "(형태: " + row["형태"].ToString() + ") \n" + "(항목: " + svcarea + ") ";

                schedule.NURSEMEMO = nurseMemo;

                schedule.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
                resvList.Add(schedule);

                if (resvList.Count() == size)
                    break;
            }

            return resvList;
        }
        public List<CUSTOMERSCHEDULE> ReadConsultSchedule(int startRow, int size)
        {
            var consultList = new List<CUSTOMERSCHEDULE>();
            int count = 0;

            foreach (DataRow row in excelDataTable.Rows)
            {
                count++;
                if (count < startRow)
                    continue;


                //MytPro//
                //상담
                var consult = new CUSTOMERSCHEDULE();
                consult.ORGID = _orgID;
                
                consult.SCHEDULEDATE = row["상담일"].ToString().Replace("-", "");
                consult.SCHEDULETIME = "1330";
                consult.CONSULTTIME = consult.SCHEDULEDATE + consult.SCHEDULETIME;
                consult.SCHEDULESTATUS = "2";
                consult.CUSTNAME = row["고객"].ToString();
                consult.CUSTNO = row["차트번호"].ToString();

                consult.SCHNURSE = row["상담자"].ToString();
                consult.SCHDOCTOR = row["의사"].ToString();

                var cnstPart = "";
                var tmpPart = row["상담부위"].ToString();
                var PartArray = tmpPart.Split(',');

                for (var i = 0; i < PartArray.Count(); i++)
                {
                    if (PartArray[i] == "") continue;
                    if (cnstPart != "") cnstPart += ", ";
                    if (PartArray[i] == "47") { cnstPart += "눈-매몰"; }
                    if (PartArray[i] == "50") { cnstPart += "눈-절개"; }
                    if (PartArray[i] == "51") { cnstPart += "눈-매몰/비절개눈매교정"; }
                    if (PartArray[i] == "52") { cnstPart += "눈-비절개눈매교정"; }
                    if (PartArray[i] == "53") { cnstPart += "눈-절개눈매교정"; }
                    if (PartArray[i] == "55") { cnstPart += "눈-상안검"; }
                    if (PartArray[i] == "58") { cnstPart += "눈-하안검"; }
                    if (PartArray[i] == "59") { cnstPart += "눈-눈썹거상"; }
                    if (PartArray[i] == "60") { cnstPart += "눈-앞트임"; }
                    if (PartArray[i] == "61") { cnstPart += "눈-뒤트임"; }
                    if (PartArray[i] == "64") { cnstPart += "눈-밑트임"; }
                    if (PartArray[i] == "65") { cnstPart += "눈-뒤,밑트임"; }
                    if (PartArray[i] == "67") { cnstPart += "눈-앞,뒤,밑트임"; }
                    if (PartArray[i] == "69") { cnstPart += "눈-눈밑지방제거"; }
                    if (PartArray[i] == "71") { cnstPart += "눈-절개/절개눈매교정"; }
                    if (PartArray[i] == "72") { cnstPart += "눈성형"; }
                    if (PartArray[i] == "73") { cnstPart += "코성형"; }
                    if (PartArray[i] == "74") { cnstPart += "코-콧대"; }
                    if (PartArray[i] == "75") { cnstPart += "코-코끝"; }
                    if (PartArray[i] == "76") { cnstPart += "코-콧대,코끝"; }
                    if (PartArray[i] == "78") { cnstPart += "코-콧볼축소"; }
                    if (PartArray[i] == "103") { cnstPart += "코-메부리"; }
                    if (PartArray[i] == "104") { cnstPart += "코-절골"; }
                    if (PartArray[i] == "105") { cnstPart += "코-메부리,절골"; }
                    if (PartArray[i] == "106") { cnstPart += "코-휜코"; }
                    if (PartArray[i] == "107") { cnstPart += "코-화살코"; }
                    if (PartArray[i] == "108") { cnstPart += "코-짧은코(들창코)"; }
                    if (PartArray[i] == "109") { cnstPart += "코-코연장"; }
                    if (PartArray[i] == "110") { cnstPart += "코-콧구멍내리기"; }
                    if (PartArray[i] == "111") { cnstPart += "코-늑연골"; }
                    if (PartArray[i] == "112") { cnstPart += "가슴-보형물"; }
                    if (PartArray[i] == "113") { cnstPart += "가슴-물방울"; }
                    if (PartArray[i] == "114") { cnstPart += "가슴-보형물,거상(o자형절개"; }
                    if (PartArray[i] == "115") { cnstPart += "가슴-보형물,거상(유륜절개)"; }
                    if (PartArray[i] == "116") { cnstPart += "가슴-가슴축소"; }
                    if (PartArray[i] == "117") { cnstPart += "가슴-유두축소"; }
                    if (PartArray[i] == "118") { cnstPart += "가슴-함몰유두"; }
                    if (PartArray[i] == "119") { cnstPart += "가슴-보형물제거"; }
                    if (PartArray[i] == "120") { cnstPart += "윤곽-사각턱"; }
                    if (PartArray[i] == "121") { cnstPart += "윤곽-광대"; }
                    if (PartArray[i] == "122") { cnstPart += "윤곽-앞턱T절골"; }
                    if (PartArray[i] == "123") { cnstPart += "윤곽-앞턱보형물"; }
                    if (PartArray[i] == "124") { cnstPart += "윤곽-사각턱+광대"; }
                    if (PartArray[i] == "125") { cnstPart += "윤곽-귀족보형물"; }
                    if (PartArray[i] == "126") { cnstPart += "이마-보형물(확장)"; }
                    if (PartArray[i] == "127") { cnstPart += "이마-보형물"; }
                    if (PartArray[i] == "128") { cnstPart += "관자-보형물"; }
                    if (PartArray[i] == "129") { cnstPart += "보형물제거"; }
                    if (PartArray[i] == "130") { cnstPart += "지방흡입-복부(상,하)"; }
                    if (PartArray[i] == "131") { cnstPart += "지방흡입-복부성형"; }
                    if (PartArray[i] == "132") { cnstPart += "지방흡입-옆구리"; }
                    if (PartArray[i] == "133") { cnstPart += "지방흡입-뒷구리"; }
                    if (PartArray[i] == "134") { cnstPart += "지방흡입-복부,옆구리,뒷구리"; }
                    if (PartArray[i] == "135") { cnstPart += "지방흡입-팔"; }
                    if (PartArray[i] == "136") { cnstPart += "지방흡입-종아리"; }
                    if (PartArray[i] == "137") { cnstPart += "지방흡입-허벅지"; }
                    if (PartArray[i] == "138") { cnstPart += "지방흡입-등"; }
                    if (PartArray[i] == "139") { cnstPart += "안면거상"; }
                    if (PartArray[i] == "140") { cnstPart += "안면거상(볼)"; }
                    if (PartArray[i] == "141") { cnstPart += "이마리프팅"; }
                    if (PartArray[i] == "142") { cnstPart += "목리프팅"; }
                    if (PartArray[i] == "143") { cnstPart += "눈가주름리프팅"; }
                    if (PartArray[i] == "144") { cnstPart += "리프팅-TR라인"; }
                    if (PartArray[i] == "145") { cnstPart += "리프팅-V리프팅"; }
                    if (PartArray[i] == "146") { cnstPart += "지방이식"; }
                    if (PartArray[i] == "147") { cnstPart += "PRP지방이식"; }
                    if (PartArray[i] == "148") { cnstPart += "줄기세포지방이식"; }
                    if (PartArray[i] == "149") { cnstPart += "젤틱"; }
                    if (PartArray[i] == "150") { cnstPart += "필러"; }
                    if (PartArray[i] == "151") { cnstPart += "보톡스"; }
                    if (PartArray[i] == "152") { cnstPart += "더모톡신"; }
                    if (PartArray[i] == "153") { cnstPart += "쁘띠윤곽"; }
                    if (PartArray[i] == "154") { cnstPart += "지방흡입"; }
                    if (PartArray[i] == "155") { cnstPart += "피부"; }
                    if (PartArray[i] == "156") { cnstPart += "바디라인"; }
                    if (PartArray[i] == "157") { cnstPart += "반영구화장"; }
                    if (PartArray[i] == "158") { cnstPart += "모발이식"; }
                    if (PartArray[i] == "159") { cnstPart += "눈"; }
                }

                var cnstType1 = "";
                var tmpType1 = row["상담구분1"].ToString();
                var typeArray = tmpType1.Split(',');

                for (var j = 0; j < typeArray.Count(); j++)
                {
                    if (typeArray[j] == "") continue;
                    if (cnstType1 != "") cnstType1 += ", ";
                    if (typeArray[j] == "3") { cnstType1 += "굿닥"; }
                    if (typeArray[j] == "4") { cnstType1 += "바비톡"; }
                    if (typeArray[j] == "5") { cnstType1 += "페이스북"; }
                    if (typeArray[j] == "9") { cnstType1 += "네이버"; }
                    if (typeArray[j] == "10") { cnstType1 += "고객소개"; }
                    if (typeArray[j] == "20") { cnstType1 += "sms"; }
                    if (typeArray[j] == "21") { cnstType1 += "직원/외부실장"; }
                }

                var cnstType2 = "";
                var tmpType2 = row["상담구분2"].ToString();
                var type2Array = tmpType2.Split(',');

                for (var k = 0; k < type2Array.Count(); k++)
                {
                    if (type2Array[k] == "") continue;
                    if (cnstType2 != "") cnstType2 += ", ";

                    if (type2Array[k] == "2") { cnstType2 += "부분사진공개"; }
                    if (type2Array[k] == "6") { cnstType2 += "전체사진공개"; }
                    if (type2Array[k] == "7") { cnstType2 += "동의가능서8"; }
                    if (type2Array[k] == "11") { cnstType2 += "동의가능성7"; }
                    if (type2Array[k] == "12") { cnstType2 += "동의가능성6"; }
                    if (type2Array[k] == "13") { cnstType2 += "동의가능성5"; }
                    if (type2Array[k] == "14") { cnstType2 += "동의가능성4"; }
                    if (type2Array[k] == "15") { cnstType2 += "동의가능성3"; }
                    if (type2Array[k] == "16") { cnstType2 += "동의가능성2"; }
                    if (type2Array[k] == "17") { cnstType2 += "동의가능성1"; }
                    if (type2Array[k] == "18") { cnstType2 += "동의가능성0"; }
                    if (type2Array[k] == "19") { cnstType2 += "인콜"; }
                    if (type2Array[k] == "22") { cnstType2 += "20대"; }
                }

                consult.PROGRESSNOTE = "(상담부위: " + cnstPart + ", 상담구분1: " + cnstType1 + ", 상담구분2: " + cnstType2 + ") ";

                var cnstMemo = System.Text.RegularExpressions.Regex.Replace(row["상담내용"].ToString(), @"<(.|\n)*?>", string.Empty);
                consult.CONSULTNOTE = "(상담내용: " + cnstMemo + ",\n 상담결과: " + row["상담결과"].ToString() + ") ";
                /*
                var cnstMemo = System.Text.RegularExpressions.Regex.Replace(row["상담내용"].ToString(), @"<(.|\n)*?>", string.Empty);
                consult.MEMO = memoDate + "\n" + "(의사: " + doctor + ", 상담자: " + consult.EMPLNAME + ") \n";
                consult.MEMO += "(상담부위: " + cnstPart + ", 상담구분1: " + cnstType1 + ", 상담구분2: " + cnstType2 + ", 상담유형:" + row["상담유형"].ToString() + ")\n";
                consult.MEMO += cnstMemo;
                */
                consult.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
                consultList.Add(consult);

                if (consultList.Count() == size)
                    break;
            }

            return consultList;
        }
        public List<CUSTOMERMEMO> ReadConsultScheduleV1(int startRow, int size)
        {
            var consultList = new List<CUSTOMERMEMO>();
            int count = 0;

            foreach (DataRow row in excelDataTable.Rows)
            {
                count++;
                if (count < startRow)
                    continue;


                //MytPro//
                //상담
                var consult = new CUSTOMERMEMO();
                consult.ORGID = _orgID;

                consult.MEMOTYPE = "4";
                var memoDate = row["상담일"].ToString();
                consult.MEMODATE = memoDate.Replace("-", "");
                consult.CUSTNAME = row["고객"].ToString();
                consult.CUSTNO = row["차트번호"].ToString();
                var cnstNurse = row["상담자"].ToString();
                if (cnstNurse == "NULL") cnstNurse = "";
                consult.EMPLNAME = cnstNurse;
                consult.USERID = consult.EMPLNAME;

                var cnstPart = "";
                var tmpPart = row["상담부위"].ToString();
                var PartArray = tmpPart.Split(',');

                for(var i=0; i < PartArray.Count(); i++)
                {
                    if (PartArray[i] == "") continue;
                    if (cnstPart != "") cnstPart += ", ";
                    if (PartArray[i] == "47") { cnstPart += "눈-매몰"; }
                    if (PartArray[i] == "50") { cnstPart += "눈-절개"; }
                    if (PartArray[i] == "51") { cnstPart += "눈-매몰/비절개눈매교정"; }
                    if (PartArray[i] == "52") { cnstPart += "눈-비절개눈매교정"; }
                    if (PartArray[i] == "53") { cnstPart += "눈-절개눈매교정"; }
                    if (PartArray[i] == "55") { cnstPart += "눈-상안검"; }
                    if (PartArray[i] == "58") { cnstPart += "눈-하안검"; }
                    if (PartArray[i] == "59") { cnstPart += "눈-눈썹거상"; }
                    if (PartArray[i] == "60") { cnstPart += "눈-앞트임"; }
                    if (PartArray[i] == "61") { cnstPart += "눈-뒤트임"; }
                    if (PartArray[i] == "64") { cnstPart += "눈-밑트임"; }
                    if (PartArray[i] == "65") { cnstPart += "눈-뒤,밑트임"; }
                    if (PartArray[i] == "67") { cnstPart += "눈-앞,뒤,밑트임"; }
                    if (PartArray[i] == "69") { cnstPart += "눈-눈밑지방제거"; }
                    if (PartArray[i] == "71") { cnstPart += "눈-절개/절개눈매교정"; }
                    if (PartArray[i] == "72") { cnstPart += "눈성형"; }
                    if (PartArray[i] == "73") { cnstPart += "코성형"; }
                    if (PartArray[i] == "74") { cnstPart += "코-콧대"; }
                    if (PartArray[i] == "75") { cnstPart += "코-코끝"; }
                    if (PartArray[i] == "76") { cnstPart += "코-콧대,코끝"; }
                    if (PartArray[i] == "78") { cnstPart += "코-콧볼축소"; }
                    if (PartArray[i] == "103") { cnstPart += "코-메부리"; }
                    if (PartArray[i] == "104") { cnstPart += "코-절골"; }
                    if (PartArray[i] == "105") { cnstPart += "코-메부리,절골"; }
                    if (PartArray[i] == "106") { cnstPart += "코-휜코"; }
                    if (PartArray[i] == "107") { cnstPart += "코-화살코"; }
                    if (PartArray[i] == "108") { cnstPart += "코-짧은코(들창코)"; }
                    if (PartArray[i] == "109") { cnstPart += "코-코연장"; }
                    if (PartArray[i] == "110") { cnstPart += "코-콧구멍내리기"; }
                    if (PartArray[i] == "111") { cnstPart += "코-늑연골"; }
                    if (PartArray[i] == "112") { cnstPart += "가슴-보형물"; }
                    if (PartArray[i] == "113") { cnstPart += "가슴-물방울"; }
                    if (PartArray[i] == "114") { cnstPart += "가슴-보형물,거상(o자형절개"; }
                    if (PartArray[i] == "115") { cnstPart += "가슴-보형물,거상(유륜절개)"; }
                    if (PartArray[i] == "116") { cnstPart += "가슴-가슴축소"; }
                    if (PartArray[i] == "117") { cnstPart += "가슴-유두축소"; }
                    if (PartArray[i] == "118") { cnstPart += "가슴-함몰유두"; }
                    if (PartArray[i] == "119") { cnstPart += "가슴-보형물제거"; }
                    if (PartArray[i] == "120") { cnstPart += "윤곽-사각턱"; }
                    if (PartArray[i] == "121") { cnstPart += "윤곽-광대"; }
                    if (PartArray[i] == "122") { cnstPart += "윤곽-앞턱T절골"; }
                    if (PartArray[i] == "123") { cnstPart += "윤곽-앞턱보형물"; }
                    if (PartArray[i] == "124") { cnstPart += "윤곽-사각턱+광대"; }
                    if (PartArray[i] == "125") { cnstPart += "윤곽-귀족보형물"; }
                    if (PartArray[i] == "126") { cnstPart += "이마-보형물(확장)"; }
                    if (PartArray[i] == "127") { cnstPart += "이마-보형물"; }
                    if (PartArray[i] == "128") { cnstPart += "관자-보형물"; }
                    if (PartArray[i] == "129") { cnstPart += "보형물제거"; }
                    if (PartArray[i] == "130") { cnstPart += "지방흡입-복부(상,하)"; }
                    if (PartArray[i] == "131") { cnstPart += "지방흡입-복부성형"; }
                    if (PartArray[i] == "132") { cnstPart += "지방흡입-옆구리"; }
                    if (PartArray[i] == "133") { cnstPart += "지방흡입-뒷구리"; }
                    if (PartArray[i] == "134") { cnstPart += "지방흡입-복부,옆구리,뒷구리"; }
                    if (PartArray[i] == "135") { cnstPart += "지방흡입-팔"; }
                    if (PartArray[i] == "136") { cnstPart += "지방흡입-종아리"; }
                    if (PartArray[i] == "137") { cnstPart += "지방흡입-허벅지"; }
                    if (PartArray[i] == "138") { cnstPart += "지방흡입-등"; }
                    if (PartArray[i] == "139") { cnstPart += "안면거상"; }
                    if (PartArray[i] == "140") { cnstPart += "안면거상(볼)"; }
                    if (PartArray[i] == "141") { cnstPart += "이마리프팅"; }
                    if (PartArray[i] == "142") { cnstPart += "목리프팅"; }
                    if (PartArray[i] == "143") { cnstPart += "눈가주름리프팅"; }
                    if (PartArray[i] == "144") { cnstPart += "리프팅-TR라인"; }
                    if (PartArray[i] == "145") { cnstPart += "리프팅-V리프팅"; }
                    if (PartArray[i] == "146") { cnstPart += "지방이식"; }
                    if (PartArray[i] == "147") { cnstPart += "PRP지방이식"; }
                    if (PartArray[i] == "148") { cnstPart += "줄기세포지방이식"; }
                    if (PartArray[i] == "149") { cnstPart += "젤틱"; }
                    if (PartArray[i] == "150") { cnstPart += "필러"; }
                    if (PartArray[i] == "151") { cnstPart += "보톡스"; }
                    if (PartArray[i] == "152") { cnstPart += "더모톡신"; }
                    if (PartArray[i] == "153") { cnstPart += "쁘띠윤곽"; }
                    if (PartArray[i] == "154") { cnstPart += "지방흡입"; }
                    if (PartArray[i] == "155") { cnstPart += "피부"; }
                    if (PartArray[i] == "156") { cnstPart += "바디라인"; }
                    if (PartArray[i] == "157") { cnstPart += "반영구화장"; }
                    if (PartArray[i] == "158") { cnstPart += "모발이식"; }
                    if (PartArray[i] == "159") { cnstPart += "눈"; }
                }

                var cnstType1 = "";
                var tmpType1 = row["상담구분1"].ToString();
                var typeArray = tmpType1.Split(',');

                for(var j=0; j<typeArray.Count(); j++)
                {
                    if (typeArray[j] == "") continue;
                    if (cnstType1 != "") cnstType1 += ", ";
                    if (typeArray[j] == "3") { cnstType1 += "굿닥"; }
                    if (typeArray[j] == "4") { cnstType1 += "바비톡"; }
                    if (typeArray[j] == "5") { cnstType1 += "페이스북"; }
                    if (typeArray[j] == "9") { cnstType1 += "네이버"; }
                    if (typeArray[j] == "10") { cnstType1 += "고객소개"; }
                    if (typeArray[j] == "20") { cnstType1 += "sms"; }
                    if (typeArray[j] == "21") { cnstType1 += "직원/외부실장"; }
                }

                var cnstType2 = "";
                var tmpType2 = row["상담구분2"].ToString();
                var type2Array = tmpType2.Split(',');

                for(var k=0; k<type2Array.Count(); k++)
                {
                    if (type2Array[k] == "") continue;
                    if (cnstType2 != "") cnstType2 += ", ";

                    if (type2Array[k] == "2") { cnstType2 += "부분사진공개"; }
                    if (type2Array[k] == "6") { cnstType2 += "전체사진공개"; }
                    if (type2Array[k] == "7") { cnstType2 += "동의가능서8"; }
                    if (type2Array[k] == "11") { cnstType2 += "동의가능성7"; }
                    if (type2Array[k] == "12") { cnstType2 += "동의가능성6"; }
                    if (type2Array[k] == "13") { cnstType2 += "동의가능성5"; }
                    if (type2Array[k] == "14") { cnstType2 += "동의가능성4"; }
                    if (type2Array[k] == "15") { cnstType2 += "동의가능성3"; }
                    if (type2Array[k] == "16") { cnstType2 += "동의가능성2"; }
                    if (type2Array[k] == "17") { cnstType2 += "동의가능성1"; }
                    if (type2Array[k] == "18") { cnstType2 += "동의가능성0"; }
                    if (type2Array[k] == "19") { cnstType2 += "인콜"; }
                    if (type2Array[k] == "22") { cnstType2 += "20대"; }
                }

                var doctor = row["의사"].ToString();
                if (doctor == "NULL") doctor = "";

                var cnstMemo = System.Text.RegularExpressions.Regex.Replace(row["상담내용"].ToString(), @"<(.|\n)*?>", string.Empty);
                consult.MEMO = memoDate + "\n" + "(의사: " + doctor + ", 상담자: " + consult.EMPLNAME + ") \n";
                consult.MEMO += "(상담부위: " + cnstPart + ", 상담구분1: " + cnstType1 + ", 상담구분2: " + cnstType2 + ", 상담유형:" + row["상담유형"].ToString() + ")\n";
                consult.MEMO += cnstMemo;

                consult.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
                consultList.Add(consult);

                if (consultList.Count() == size)
                    break;
            }

            return consultList;
        }
        //ReadPaymentSchedule
        public List<PAYMENT> ReadPaymentSchedule(int startRow, int size)
        {
            var payList = new List<PAYMENT>();
            int count = 0;

            foreach (DataRow row in excelDataTable.Rows)
            {
                count++;
                if (count < startRow)
                    continue;
                
                //MytPro//
                //수납
                var listCnt = 0;


                //payment.PAYMENTAMT = row["합계"].ToString();
                

                var c00 = row["카드"].ToString();
                if(c00 != "0")
                {
                    var payment = new PAYMENT();
                    payment.ORGID = _orgID;

                    // static
                    payment.EMPLOYEEID = "0";
                    // excel
                    payment.PAYDATE = row["수납일"].ToString().Replace("-", "");
                    payment.ORDERDATE = payment.PAYDATE;
                    payment.DESCRIPTION = row["memo"].ToString();

                    payment.CUSTNAME = row["성명"].ToString();
                    payment.CUSTNO = row["차트번호"].ToString();
                    //payment.CONSULTNOTE = "(대분류: " + row["대분류"].ToString() + ", 소분류: " + row["소분류"].ToString() + ")";
                    payment.ASSESSMENT = "(대분류: " + row["대분류"].ToString() + ", 소분류: " + row["소분류"].ToString() + ")";

                    payment.TOTALPRICE = row["합계"].ToString();
                    payment.TAX = (int.Parse(payment.TOTALPRICE) / 11).ToString();
                    payment.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
                    payment.PAYMENTCODE = "C00";
                    payment.PAYMENTAMT = c00;
                    payment.REFUNDFLAG = "0";

                    if (int.Parse(c00) < 0)
                    {
                        payment.PAYMENTCODE = "R02";
                        payment.REFUNDFLAG = "1";
                        payment.PAYMENTAMT = c00.Replace("-", "");
                    }
                    payList.Add(payment);
                    listCnt++;
                }
                var m03 = row["현영"].ToString();
                if(m03 != "0")
                {
                    var payment = new PAYMENT();
                    payment.ORGID = _orgID;

                    // static
                    payment.EMPLOYEEID = "0";
                    // excel
                    payment.PAYDATE = row["수납일"].ToString().Replace("-", "");
                    payment.ORDERDATE = payment.PAYDATE;
                    payment.DESCRIPTION = row["memo"].ToString();

                    payment.CUSTNAME = row["성명"].ToString();
                    payment.CUSTNO = row["차트번호"].ToString();
                    //payment.CONSULTNOTE = "(대분류: " + row["대분류"].ToString() + ", 소분류: " + row["소분류"].ToString() + ")";
                    payment.ASSESSMENT = "(대분류: " + row["대분류"].ToString() + ", 소분류: " + row["소분류"].ToString() + ")";

                    payment.TOTALPRICE = row["합계"].ToString();
                    payment.TAX = (int.Parse(payment.TOTALPRICE) / 11).ToString();
                    payment.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
                    payment.PAYMENTCODE = "M03";
                    payment.RECEIPTISSUE = "1";
                    payment.PAYMENTAMT = m03;
                    payment.REFUNDFLAG = "0";

                    if (int.Parse(m03) < 0)
                    {
                        payment.PAYMENTCODE = "R01";
                        payment.RECEIPTISSUE = "0";
                        payment.REFUNDFLAG = "1";
                        payment.PAYMENTAMT = m03.Replace("-", "");
                    }
                    payList.Add(payment);
                    listCnt++;
                }
                var m01 = row["현금"].ToString();
                if(m01 != "0")
                {
                    var payment = new PAYMENT();
                    payment.ORGID = _orgID;

                    // static
                    payment.EMPLOYEEID = "0";
                    // excel
                    payment.PAYDATE = row["수납일"].ToString().Replace("-", "");
                    payment.ORDERDATE = payment.PAYDATE;
                    payment.DESCRIPTION = row["memo"].ToString();

                    payment.CUSTNAME = row["성명"].ToString();
                    payment.CUSTNO = row["차트번호"].ToString();
                    //payment.CONSULTNOTE = "(대분류: " + row["대분류"].ToString() + ", 소분류: " + row["소분류"].ToString() + ")";
                    payment.ASSESSMENT = "(대분류: " + row["대분류"].ToString() + ", 소분류: " + row["소분류"].ToString() + ")";

                    payment.TOTALPRICE = row["합계"].ToString();
                    payment.TAX = (int.Parse(payment.TOTALPRICE) / 11).ToString();
                    payment.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
                    payment.PAYMENTCODE = "M01";
                    payment.PAYMENTAMT = m01;
                    payment.REFUNDFLAG = "0";

                    if (int.Parse(m01) < 0)
                    {
                        payment.PAYMENTCODE = "R01";
                        payment.REFUNDFLAG = "1";
                        payment.PAYMENTAMT = m01.Replace("-", "");
                    }
                    payList.Add(payment);
                    listCnt++;
                }
                var m02 = row["통장"].ToString();
                if(m02 != "0")
                {
                    var payment = new PAYMENT();
                    payment.ORGID = _orgID;

                    // static
                    payment.EMPLOYEEID = "0";
                    // excel
                    payment.PAYDATE = row["수납일"].ToString().Replace("-", "");
                    payment.ORDERDATE = payment.PAYDATE;
                    payment.DESCRIPTION = row["memo"].ToString();

                    payment.CUSTNAME = row["성명"].ToString();
                    payment.CUSTNO = row["차트번호"].ToString();
                    //payment.CONSULTNOTE = "(대분류: " + row["대분류"].ToString() + ", 소분류: " + row["소분류"].ToString() + ")";
                    payment.ASSESSMENT = "(대분류: " + row["대분류"].ToString() + ", 소분류: " + row["소분류"].ToString() + ")";

                    payment.TOTALPRICE = row["합계"].ToString();
                    payment.TAX = (int.Parse(payment.TOTALPRICE) / 11).ToString();
                    payment.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
                    payment.PAYMENTCODE = "M02";
                    payment.PAYMENTAMT = m02;
                    payment.REFUNDFLAG = "0";

                    if (int.Parse(m02) < 0)
                    {
                        payment.PAYMENTCODE = "R03";
                        payment.REFUNDFLAG = "1";
                        payment.PAYMENTAMT = m02.Replace("-", "");
                    }
                    payList.Add(payment);
                    listCnt++;
                }
                
                if(listCnt > 1)
                {
                    size += listCnt - 1;
                }
                if (payList.Count() == size)
                    break;
            }

            return payList;
        }
        //public List<CUSTOMERSCHEDULE> ReadSchedule(string year, int startRow, int size)
        //{
        //    var customerList = new List<CUSTOMERSCHEDULE>();
        //    int count = 0;
        //    //수납일 성명 차트번호 대분류 소분류 합계 카드 현영 현금 통장 미수 memo																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																				

        //    foreach (DataRow row in excelDataTable.Rows)
        //    {
        //        count++;
        //        if (count < startRow)
        //            continue;

        //        //수납일 성명 차트번호 대분류 소분류 합계 카드 현영 현금 통장 미수 memo

        //        //MytPro//
        //        //수납
        //        var cust = new CUSTOMERSCHEDULE();
        //        cust.ORGID = _orgID;
        //        cust.RESVMEMO = row["성명"].ToString();  //성명 - RESVMEMO
        //        cust.NURSEMEMO = row["차트번호"].ToString().Replace("-", ""); //차트번호 - NURSEMEMO
        //        cust.SCHEDULEDATE = row["수납일"].ToString().Replace("-", "");
        //        //string category = row["(대분류,소분류)"].ToString();
        //        string mainCategory = row["대분류"].ToString();
        //        string subCategory = row["소분류"].ToString();
        //        if (subCategory == "NULL") subCategory = "";
        //        string memo = row["memo"].ToString();

        //        cust.CONSULTNOTE = "(" + mainCategory + "," + subCategory + ")" + memo; //상담내용
        //        cust.CONSULTTIME = cust.SCHEDULEDATE + "120000";
        //        cust.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
        //        cust.INSTYPE = 2;

        //        cust.mtpTOTAL = row["합계"].ToString();
        //        cust.mtpCard = row["카드"].ToString();
        //        cust.mtpCashReceipt = row["현영"].ToString();
        //        cust.mtpCash = row["현금"].ToString();
        //        cust.mtpBankBook = row["통장"].ToString();
        //        cust.mtpUnpaid = row["미수"].ToString();
        //        //
        //        // cust.RESVCOUNT = row["이름"].ToString();
        //        //cust.PROGRESSNOTE = row["병명"].ToString() + "\n";
        //        //cust.PROGRESSNOTE = cust.PROGRESSNOTE + row["수술내용"].ToString();

        //        //cust.SCHEDULEDATE = row["수술일자"].ToString().Replace("-", "");

        //        //cust.NURSEMEMO = row["집도의"].ToString();
        //        //cust.SCHEDULETIME = "120000";
        //        //cust.CONSULTTIME = cust.SCHEDULEDATE + "120000";
        //        //cust.CONSULTNOTE = row["수술비"].ToString();
        //        //cust.CONSULTNOTE = cust.CONSULTNOTE + cust.CONSULTNOTE + row["결재방법"].ToString();
        //        //cust.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
        //        //cust.INSTYPE = 2;
        //        customerList.Add(cust);

        //        if (customerList.Count() == size)
        //            break;
        //    }

        //    return customerList;
        //}
        // MytPro Update Schedule
        //public List<CUSTOMERSCHEDULE> UpdateSchedule(int startRow, int size)
        //{
        //    var customerList = new List<CUSTOMERSCHEDULE>();
        //    int count = 0;
        //    //작성일 성명 차트번호 의사 담당자 대분류 소분류 차트내용HTML																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																				

        //    foreach (DataRow row in excelDataTable.Rows)
        //    {
        //        count++;
        //        if (count < startRow)
        //            continue;

        //        //수납일 성명 차트번호 대분류 소분류 합계 카드 현영 현금 통장 미수 memo

        //        //MytPro//
        //        //진료차트
        //        var cust = new CUSTOMERSCHEDULE();
        //        cust.ORGID = _orgID;
        //        cust.RESVMEMO = row["성명"].ToString();  //성명 - RESVMEMO
        //        cust.NURSEMEMO = row["차트번호"].ToString(); //차트번호 - NURSEMEMO
        //        cust.SCHEDULEDATE = row["작성일"].ToString().Replace("-", "");
        //        cust.HISTMEMO = row["의사"].ToString(); //의사 - HISTMEMO

        //        string category = row["(담당자,대분류,소분류)"].ToString();
        //        string chart = row["차트내용HTML  (증상경과)"].ToString();

        //        chart = System.Text.RegularExpressions.Regex.Replace(chart, @"<(.|\n)*?>", string.Empty);
        //        chart = chart.Replace("&nbsp;", "");
        //        chart = chart.Replace("&amp;", "");
        //        cust.PROGRESSNOTE = category+"\n"+ chart; //증상경과

        //        string receiptMemo = row["전달사항 (명세서 메모)"].ToString();
        //        receiptMemo = System.Text.RegularExpressions.Regex.Replace(receiptMemo, @"<(.|\n)*?>", string.Empty);   //HTML 소스 제거
        //        receiptMemo = receiptMemo.Replace("&nbsp;", "");
        //        receiptMemo = receiptMemo.Replace("&amp;", "");
        //        cust.ASSESSMENT = receiptMemo;

        //        cust.CONSULTTIME = cust.SCHEDULEDATE + "120000";
        //        cust.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");

        //        //
        //        customerList.Add(cust);

        //        if (customerList.Count() == size)
        //            break;
        //    }

        //    return customerList;
        //}
        // MytPro CustomerMemo
        public List<CUSTOMERMEMO> ReadCustomerMemo(string year, int startRow, int size)
        {
            var customerList = new List<CUSTOMERMEMO>();
            int count = 0;
            //																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																		

            foreach (DataRow row in excelDataTable.Rows)
            {
                count++;
                if (count < startRow)
                    continue;

                var cust = new CUSTOMERMEMO();
                cust.ORGID = _orgID.ToString();

                //관리 차트 - 기타메모
                cust.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");

                //cust.mtpCUSTNAME = row["고객"].ToString();
                //cust.mtpCUSTNO = row["차트번호"].ToString().Replace("-", "");

                string mngName = row["관리자"].ToString().Replace("NULL", "");
                string manager = "(관리자:" + mngName + ")";
                string mgContent = row["관리내용"].ToString();
                string schDate = row["다음일정"].ToString();
                string schedule = "(다음일정:" + schDate + ")";
                mgContent = System.Text.RegularExpressions.Regex.Replace(mgContent, @"<(.|\n)*?>", string.Empty);
                mgContent = mgContent.Replace("&nbsp;", " ");
                mgContent = mgContent.Replace("&amp;", "");
                cust.MEMO = manager + "\n" + mgContent + "\n" + schedule;

                var memodate = row["상담일"].ToString();
                if (memodate.Length >= 10)
                    cust.MEMODATE = memodate.Substring(0, 10).Replace("-", "");
                else
                    cust.MEMODATE = memodate;
                cust.MEMOTYPE = "4";
                cust.CALLTYPE = "0";
                //
                // 상담차트 - IN콜 메모
                //cust.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");

                //cust.mtpCUSTNAME = row["고객"].ToString();
                //cust.mtpCUSTNO = row["차트번호"].ToString().Replace("-", "");

                //string cselor1 = row["상담자"].ToString();
                //if (cselor1 == "NULL") cselor1 = "";
                //string cselor2 = row["의사"].ToString();
                //if (cselor2 == "NULL") cselor2 = "";
                //string counselor = "(상담:" + cselor1 + ", 담당의:" + cselor2 + ")";

                //string csContent = row["상담내용"].ToString();
                //string sch1 = row["상담결과"].ToString();
                //string sch2 = row["다음일정"].ToString();
                //string schedule = "(상담결과:" + sch1 + ", 다음일정:" + sch2 + ")";

                //csContent = System.Text.RegularExpressions.Regex.Replace(csContent, @"<(.|\n)*?>", string.Empty);
                //csContent = csContent.Replace("&nbsp;", "");
                //csContent = csContent.Replace("&amp;", "");
                //cust.MEMO = counselor + "\n" + csContent + "\n" + schedule;

                //var csdate = row["상담일"].ToString();
                //if (csdate.Length >= 10)
                //    cust.MEMODATE = csdate.Substring(0, 10).Replace("-", "");
                //else
                //    cust.MEMODATE = csdate;

                //cust.MEMOTYPE = "0";
                //cust.CALLTYPE = "1";
                //
                cust.TOP = "0";
                customerList.Add(cust);

                if (customerList.Count() == size)
                    break;
            }

            return customerList;
        }
 
        public List<CUSTOMERPERSONAL> ReadMediRegistration(int startRow, int size)
        {
            var customerList = new List<CUSTOMERPERSONAL>();
            int count = 0;
            //차트번호	이름	성별	전화번호	휴대폰1	휴대폰2	우편번호		e-메일	비고	직장(학교)	증상경과																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																				


            foreach (DataRow row in excelDataTable.Rows)
            {
                char split = '-';
                count++;
                if (count < startRow)
                    continue;

                //var r = row["중복여부"].ToString();
                //if (r != "0") continue;
                //CUSTOMERID	CUSTNAME	CUSTJN	CUSTADDR11	휴대폰번호	병명	수술일자	집도의	수술비	영수증사용	결재방법	수술내용	특기사항

                var cust = new CUSTOMERPERSONAL();

                cust.CUSTNO = row["고객번호"].ToString();

                cust.CUSTNAME = row["고객명"].ToString();

                string gender = row["성별"].ToString();
                if (gender == "남")
                {
                    cust.CUSTGENDER = "1";
                }
                else if (gender == "여")
                {
                    cust.CUSTGENDER = "2";
                }

                string tell = row["전화번호"].ToString();
                try
                {
                    string[] tellSplit = tell.Split(split);
                    tell = tellSplit[0] + tellSplit[1] + tellSplit[2];
                    cust.CUSTCELL1 = tell;
                }
                catch (Exception e)
                {
                    cust.CUSTCELL1 = "";
                }

                string cell = row["휴대폰번호"].ToString();
                try
                {
                    string[] cellSplit = cell.Split(split);
                    cell = cellSplit[0] + cellSplit[1] + cellSplit[2];
                    cust.CUSTPHONE1 = cell;
                }
                catch (Exception e) { cust.CUSTPHONE1 = ""; }

                string sms = row["문자수신"].ToString();
                if (sms == "동의")
                {
                    cust.RECVSMS = "1";
                }
                else if (sms == "거부")
                {
                    cust.RECVSMS = "2";
                }

                cust.CUSTADDR11 = row["주소"].ToString();

                string birth = row["생년월일"].ToString();
                try
                {
                    birth = birth.Substring(0, 10);
                    string[] birthSplit = birth.Split(split);
                    birth = birthSplit[0] + birthSplit[1] + birthSplit[2];
                    cust.CUSTDOB = birth;
                }
                catch (Exception e) { cust.CUSTDOB = ""; }

                string crtime = row["최초방문일"].ToString();
                try
                {
                    crtime = crtime.Substring(0, 10);
                    string[] crtimeSplit = crtime.Split(split);
                    crtime = crtimeSplit[0] + crtimeSplit[1] + crtimeSplit[2];
                    cust.CUSTREGDATE = crtime;
                }
                catch (Exception e) { cust.CUSTREGDATE = ""; }

                cust.CUSTMEMO = row["비고"].ToString();

                customerList.Add(cust);

                if (customerList.Count() == size)
                    break;
            }

            return customerList;
        }

        //public override List<MediClinicItem> ReadMediClinicItem(int startRow, int size)
        //{
        //    var itemList = new List<MediClinicItem>();
        //    int count = 0;
        //    //차트번호	이름	성별	전화번호	휴대폰1	휴대폰2	우편번호		e-메일	비고	직장(학교)	증상경과																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																				


        //    foreach (DataRow row in excelDataTable.Rows)
        //    {
        //        count++;
        //        if (count < startRow)
        //            continue;

        //        //var r = row["중복여부"].ToString();
        //        //if (r != "0") continue;
        //        //CUSTOMERID	CUSTNAME	CUSTJN	CUSTADDR11	휴대폰번호	병명	수술일자	집도의	수술비	영수증사용	결재방법	수술내용	특기사항

        //        var item = new MediClinicItem();

        //        item.RCIP_CNUM = row["RCIP_CNUM"].ToString();
        //        item.CLNC_GUBN = row["CLNC_GUBN"].ToString();
        //        item.CLIT_SEQN = row["CLIT_SEQN"].ToString();
        //        item.CLNC_DOCT = row["CLNC_DOCT"].ToString();
        //        item.RMDY_CODE = row["RMDY_CODE"].ToString();
        //        item.CLNC_CODE = row["CLNC_CODE"].ToString();
        //        item.UNRG_INFO = row["UNRG_INFO"].ToString();
        //        item.EMPL_SEQN = row["EMPL_SEQN"].ToString();
        //        item.PART_FLAG = row["PART_FLAG"].ToString();
        //        item.MONY_GUBN = row["MONY_GUBN"].ToString();
        //        item.CLNC_MONY = row["CLNC_MONY"].ToString();
        //        item.CNIT_SEQN = row["CNIT_SEQN"].ToString();
        //        item.COUN_RCIP = row["COUN_RCIP"].ToString();
        //        item.AFTR_YYMD = row["AFTR_YYMD"].ToString();
        //        item.UPDT_DATE = row["UPDT_DATE"].ToString();
        //        item.UPDT_USER = row["UPDT_USER"].ToString();
        //        item.AFTR_MEMO = row["AFTR_MEMO"].ToString();
        //        item.ATAX_FLAG = row["ATAX_FLAG"].ToString();

        //        itemList.Add(item);

        //        if (itemList.Count() == size)
        //            break;
        //    }
        //    return itemList;
        //}

        //public override List<MediCoupon> ReadMediCoupon(int startRow, int size)
        //{
        //    var couponList = new List<MediCoupon>();
        //    int count = 0;
        //    //차트번호	이름	성별	전화번호	휴대폰1	휴대폰2	우편번호		e-메일	비고	직장(학교)	증상경과																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																				


        //    foreach (DataRow row in excelDataTable.Rows)
        //    {
        //        count++;
        //        if (count < startRow)
        //            continue;

        //        //var r = row["중복여부"].ToString();
        //        //if (r != "0") continue;
        //        //CUSTOMERID	CUSTNAME	CUSTJN	CUSTADDR11	휴대폰번호	병명	수술일자	집도의	수술비	영수증사용	결재방법	수술내용	특기사항

        //        var coupon = new MediCoupon();

        //        coupon.CUPN_SEQN = row["CUPN_SEQN"].ToString();
        //        coupon.CUPN_CODE = row["CUPN_CODE"].ToString();
        //        coupon.TOTL_CONT = row["TOTL_CONT"].ToString();
        //        coupon.CUPN_TITL = row["CUPN_TITL"].ToString();
        //        coupon.CUPN_DESC = row["CUPN_DESC"].ToString();
        //        coupon.CUPN_MONY = row["CUPN_MONY"].ToString();
        //        coupon.CUST_CNUM = row["CUST_CNUM"].ToString();
        //        coupon.CUPN_STAT = row["CUPN_STAT"].ToString();
        //        coupon.UPDT_DATE = row["UPDT_DATE"].ToString();
        //        coupon.UPDT_USER = row["UPDT_USER"].ToString();
        //        coupon.UPDT_IPAD = row["UPDT_IPAD"].ToString();

        //        couponList.Add(coupon);

        //        if (couponList.Count() == size)
        //            break;
        //    }
        //    return couponList;
        //}

        //public override List<Schedule> ReadScheduleDoctor(string year, int startRow, int size)
        //{
        //    return null;
        //}
        //public override List<Payment> ReadPaymentCash(string year, int startRow, int size)
        //{
        //    return null;
        //}
        //public override List<Payment> ReadPaymentCard(string year, int startRow, int size)
        //{
        //    return null;
        //}
        //public override List<Disease> ReadDisease(string year, int startRow, int size)
        //{
        //    return null;
        //}
        //public override List<MedicalItem> ReadMedicalItem(string year, int startRow, int size)
        //{
        //    return null;
        //}
        //public override List<MedicalItem> ReadInsuranceItem(string year, int startRow, int size)
        //{
        //    return null;
        //}

        //public override List<MedicalItem> ReadInsuranceDrug(string year, int startRow, int size)
        //{
        //    return null;
        //}
        //public override List<Customer> ReadSmartCrmCustomer(int startRow, int size)
        //{
        //    return null;
        //}

        //public override List<MediCustomer> ReadMediCustomer(int startRow, int size)
        //{
        //    return null;
        //}

        //public override List<CustomerMemo> ReadCustomerMemoEtc(int startRow, int size)
        //{
        //    var memoList = new List<CustomerMemo>();
        //    int count = 0;

        //    foreach (DataRow row in excelDataTable.Rows)
        //    {
        //        count++;
        //        if (count < startRow)
        //            continue;

        //        var memo = new CustomerMemo();
        //        memo.MEMO = row["메모"].ToString();
        //        var descr = row["비고"].ToString();

        //        memo.MEMO = descr + ", " + memo.MEMO;
        //        if (memo.MEMO.Trim().Length < 1)
        //            continue;
        //        memo.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
        //        memo.MEMODATE = memo.CRTIME.Substring(0, 8);
        //        memo.ORGID = _orgID;
        //        //memo.MEMOTYPE = "1";
        //        //memo.CALLTYPE = "0";
        //        memo.MEMOTYPE = "4";
        //        memo.CALLTYPE = "0";
        //        memo.TOP = "0";

        //        memo.CUSTOMERID = row["차트번호"].ToString();
        //        memoList.Add(memo);

        //        if (memoList.Count() == size)
        //            break;
        //    }

        //    return memoList;
        //}

        //public override List<Product> ReadProduct(int startRow, int size)
        //{
        //    var products = new List<Product>();
        //    int count = 0;

        //    foreach (DataRow row in excelDataTable.Rows)
        //    {
        //        count++;
        //        if (count < startRow)
        //            continue;

        //        var p = new Product();
        //        p.PRDTCODE = row["청구코드"].ToString();
        //        p.PCODE = row["사용자코드"].ToString();
        //        p.ACUPOINT = "";
        //        p.POSTURE = "";
        //        /*
        //        p.ACUPOINT = row["예외"].ToString();
        //        p.POSTURE = row["원외"].ToString();
        //        if (p.ACUPOINT == "00")
        //            p.ACUPOINT = "";
        //        if (p.POSTURE == "0")
        //            p.POSTURE = "IN";
        //        else
        //            p.POSTURE = "OUT";
        //         */
        //        p.ORGID = _orgID;
        //        if (p.PRDTCODE == null || p.PRDTCODE == "")
        //        {
        //            p.PRDTNAME = row["명칭"].ToString();
        //            //p.MANUFACT = row["제약사"].ToString();
        //            p.PRDTPRICE = row["일반가"].ToString();
        //            //p.PRDTREGDATE = row["개시일"].ToString().Replace("-", "");
        //        }
        //        p.ORGID = _orgID;
        //        products.Add(p);

        //        if (products.Count() == size)
        //            break;
        //    }
        //    return products;
        //}


        //public override List<Product> ReadTemplateItem(int startRow, int size)
        //{
        //    var products = new List<Product>();
        //    int count = 0;

        //    //묶음코드	묶음타입	묶음명칭	묶음가	세부코드	세부명칭

        //    foreach (DataRow row in excelDataTable.Rows)
        //    {
        //        count++;
        //        if (count < startRow)
        //            continue;

        //        var dcode = row["상병"].ToString();
        //        if (!String.IsNullOrEmpty(dcode))
        //            continue;

        //        var p = new Product();

        //        p.ORGID = _orgID;
        //        p.PRDTDESC = row["묶음명칭"].ToString();
        //        p.MANUFACT = row["묶음타입"].ToString();
        //        p.PCODE = row["세부코드"].ToString();
        //        p.PRDTNAME = row["세부명칭"].ToString();
        //        p.PRDTREGDATE = row["묶음코드"].ToString();

        //        if (String.IsNullOrEmpty(p.PCODE))
        //            continue;

        //        products.Add(p);
        //        if (products.Count() == size)
        //            break;
        //    }
        //    return products;
        //}

        //public override List<Disease> ReadTemplateDisease(int startRow, int size)
        //{
        //    var diseases = new List<Disease>();
        //    int count = 0;

        //    //묶음코드	묶음타입	묶음명칭	묶음가	세부코드	세부명칭
        //    Disease curr = null;
        //    foreach (DataRow row in excelDataTable.Rows)
        //    {
        //        count++;
        //        if (count < startRow)
        //            continue;

        //        var dcode = row["상병"].ToString();
        //        if (String.IsNullOrEmpty(dcode) || dcode == "s140")
        //            continue;

        //        var p = new Disease();

        //        p.ORGID = _orgID;
        //        p.SCHEDULEID = row["묶음명칭"].ToString();
        //        p.DISEASECODE = dcode.ToUpper();
        //        if (curr == null || curr.SCHEDULEID != p.SCHEDULEID)
        //            p.DISEASETYPE = 1;
        //        else
        //            p.DISEASETYPE = 2;

        //        p.DISEASENAME = row["상병명"].ToString();

        //        diseases.Add(p);
        //        curr = p;
        //        if (diseases.Count() == size)
        //            break;
        //    }
        //    return diseases;
        //}

    }
}
