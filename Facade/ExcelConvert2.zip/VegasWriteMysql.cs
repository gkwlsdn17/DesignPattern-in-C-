﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;

namespace HanchartDatabase
{
    class VegasWriteMysql
    {
        public MySqlConnection conn = null;
        public ExcelReader reader;
        public MytProReader mtpreader;

        public VegasWriteMysql(string dbName)
        {
            try
            {
                string connectingString = string.Format("Server=192.168.100.5;Port=3306;Database={0};Uid=vegas;Pwd=!mgrsol123;charset=utf8;allow user variables=true;", dbName);
                conn = new MySqlConnection(connectingString);
                conn.Open();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error occurred: " + ex.Message);
            }
        }

        public void MigrateCustomerMytPro()
        {
            int startRow = 0;
            int ppl = 1000;
            int count = 0;
            List<CUSTOMERPERSONAL> custList = null;
            try
            {
                while (true)
                {
                    custList = mtpreader.ReadCustomer(startRow * ppl, ppl);
                    startRow++;
                    if (custList == null && custList.Count == 0)
                    {
                        return;
                    }

                    var command = conn.CreateCommand();

                    foreach (var cust in custList)
                    {
                        count++;
                        var queryStr1 = "SELECT CODE FROM TCONFIGCODE WHERE GROUPCODE = 1 AND CONFIG = '" + cust.CUSTLVL + "'; ";
                        command.CommandText = queryStr1;
                        var x1 = command.ExecuteScalar();
                        if(x1 != null)
                        {
                            cust.CUSTLVL = x1.ToString();
                        }
                        var queryStr2 = "SELECT CODE FROM TCONFIGCODE WHERE GROUPCODE = 10 AND CONFIG = '" + cust.CUSTINFX + "'; ";
                        command.CommandText = queryStr2;
                        var x2 = command.ExecuteScalar();
                        if (x2 != null)
                        {
                            cust.CUSTINFX = x2.ToString();
                        }

                        cust.CUSTOMERID = InsertCustomer(command, cust);
                    }
                    Console.WriteLine("PatientPersonal count = {0}", count);
                    if (custList.Count < ppl)
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        public void MigrateResvScheduleMytPro()
        {
            int startRow = 0;
            int ppl = 1000;
            int count = 0;
            List<CUSTOMERSCHEDULE> resvList = null;
            CUSTOMERMEMO memo = new CUSTOMERMEMO();
            try
            {
                while (true)
                {
                    resvList = mtpreader.ReadResvSchedule(startRow * ppl, ppl);
                    startRow++;
                    if (resvList == null && resvList.Count == 0)
                    {
                        return;
                    }

                    var command = conn.CreateCommand();

                    foreach (var resv in resvList)
                    {
                        count++;
                        var queryStr1 = "SELECT CUSTOMERID FROM TCUSTOMERPERSONAL WHERE CUSTNAME = '" + resv.CUSTNAME + "' AND CUSTNO = '" + resv.CUSTNO + "' ";
                        command.CommandText = queryStr1;
                        var x1 = command.ExecuteScalar();
                        if(x1 != null)
                        {
                            resv.CUSTOMERID = x1.ToString();

                            var queryStr2 = "SELECT EMPLOYEEID FROM TEMPLOYEE WHERE EMPLNAME = '" + resv.SCHDOCTOR + "' AND EMPLTYPE = 2 ";
                            command.CommandText = queryStr2;
                            var x2 = command.ExecuteScalar();
                            if(x2 != null)
                            {
                                resv.SCHDOCTOR = x2.ToString();
                            } else
                            {
                                resv.SCHDOCTOR = "0";
                            }
                            var queryStr3 = "SELECT EMPLOYEEID FROM TEMPLOYEE WHERE EMPLNAME = '" + resv.SCHNURSE + "' AND EMPLTYPE <> 2 ";
                            command.CommandText = queryStr3;
                            var x3 = command.ExecuteScalar();
                            if (x3 != null)
                            {
                                resv.SCHNURSE = x3.ToString();
                            }
                            else
                            {
                                resv.SCHNURSE = "0";
                            }
                            var queryStr4 = "SELECT EMPLOYEEID FROM TEMPLOYEE WHERE EMPLNAME = '" + resv.RESVEMPLID + "' ";
                            command.CommandText = queryStr4;
                            var x4 = command.ExecuteScalar();
                            if (x4 != null)
                            {
                                resv.RESVEMPLID = x4.ToString();
                            }
                            else
                            {
                                resv.RESVEMPLID = "0";
                            }
                            var queryStr5 = "SELECT CODE FROM TCONFIGCODE WHERE GROUPCODE = 5 AND CONFIG = '" + resv.SVCAREA + "' ";
                            command.CommandText = queryStr5;
                            var x5 = command.ExecuteScalar();
                            if(x5 != null)
                            {
                                resv.SVCAREA = x5.ToString();
                            }
                            else
                            {
                                resv.SVCAREA = "0";
                            }
                            var queryStr6 = "SELECT CODE FROM TCONFIGCODE WHERE GROUPCODE = 20 AND CONFIG = '" + resv.SVCAREA2 + "' ";
                            command.CommandText = queryStr6;
                            var x6 = command.ExecuteScalar();
                            if (x6 != null)
                            {
                                resv.SVCAREA2 = x6.ToString();
                            }
                            else
                            {
                                resv.SVCAREA2 = "0";
                            }

                            var schID = InsertSchedule(command, resv);
                            resv.SCHEDULEID = schID;
                            if(resv.RESVMEMO != "")
                            {
                                memo = ConvertMemoFromSchedule(resv, memo, 1);
                                InsertCustomerMemo(command, memo);
                            }
                        }

                    }
                    Console.WriteLine("Schedule count = {0}", count);
                    if (resvList.Count < ppl)
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        public void MigrateResvScheduleUpdateMytPro()
        {
            int startRow = 0;
            int ppl = 1000;
            int count = 0;
            int updateCnt = 0;
            List<CUSTOMERSCHEDULE> resvList = null;
            try
            {
                while (true)
                {
                    resvList = mtpreader.ReadResvSchedule(startRow * ppl, ppl);
                    startRow++;
                    if (resvList == null && resvList.Count == 0)
                    {
                        return;
                    }

                    var command = conn.CreateCommand();

                    foreach (var resv in resvList)
                    {
                        count++;
                        var queryStr1 = "SELECT CUSTOMERID FROM TCUSTOMERPERSONAL WHERE CUSTNAME = '" + resv.CUSTNAME + "' AND CUSTNO = '" + resv.CUSTNO + "' ";
                        command.CommandText = queryStr1;
                        var x1 = command.ExecuteScalar();
                        if (x1 != null)
                        {
                            resv.CUSTOMERID = x1.ToString();

                            var queryStr2 = "SELECT EMPLOYEEID FROM TEMPLOYEE WHERE EMPLNAME = '" + resv.SCHDOCTOR + "' AND EMPLTYPE = 2 ";
                            command.CommandText = queryStr2;
                            var x2 = command.ExecuteScalar();
                            if (x2 != null)
                            {
                                resv.SCHDOCTOR = x2.ToString();
                            }
                            else
                            {
                                resv.SCHDOCTOR = "0";
                            }
                            var queryStr3 = "SELECT EMPLOYEEID FROM TEMPLOYEE WHERE EMPLNAME = '" + resv.SCHNURSE + "' AND EMPLTYPE <> 2 ";
                            command.CommandText = queryStr3;
                            var x3 = command.ExecuteScalar();
                            if (x3 != null)
                            {
                                resv.SCHNURSE = x3.ToString();
                                var queryStr7 = "SELECT SCHEDULEID FROM TCUSTOMERSCHEDULE WHERE CUSTOMERID = '" + resv.CUSTOMERID + "' AND RESVDATE = '" + resv.RESVDATE + "' AND SCHEDULEID < 97175 ";
                                command.CommandText = queryStr7;
                                var x7 = command.ExecuteScalar();
                                if (x7 != null)
                                {
                                    resv.SCHEDULEID = x7.ToString();
                                    UpdateResvSchedule(command, resv);
                                    updateCnt++;
                                }
                            }
                            else
                            {
                                resv.SCHNURSE = "0";
                            }
                            /*
                            var queryStr4 = "SELECT EMPLOYEEID FROM TEMPLOYEE WHERE EMPLNAME = '" + resv.RESVEMPLID + "' ";
                            command.CommandText = queryStr4;
                            var x4 = command.ExecuteScalar();
                            if (x4 != null)
                            {
                                resv.RESVEMPLID = x4.ToString();
                            }
                            else
                            {
                                resv.RESVEMPLID = "0";
                            }
                            var queryStr5 = "SELECT CODE FROM TCONFIGCODE WHERE GROUPCODE = 5 AND CONFIG = '" + resv.SVCAREA + "' ";
                            command.CommandText = queryStr5;
                            var x5 = command.ExecuteScalar();
                            if (x5 != null)
                            {
                                resv.SVCAREA = x5.ToString();
                            }
                            else
                            {
                                resv.SVCAREA = "0";
                            }
                            var queryStr6 = "SELECT CODE FROM TCONFIGCODE WHERE GROUPCODE = 20 AND CONFIG = '" + resv.SVCAREA2 + "' ";
                            command.CommandText = queryStr6;
                            var x6 = command.ExecuteScalar();
                            if (x6 != null)
                            {
                                resv.SVCAREA2 = x6.ToString();
                            }
                            else
                            {
                                resv.SVCAREA2 = "0";
                            }
                            */
                            
                        }

                    }
                    Console.WriteLine("Schedule count = {0}", count);
                    Console.WriteLine("UpdateCount = {0}", updateCnt);
                    if (resvList.Count < ppl)
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        public void UpdateResvSchedule(MySqlCommand command, CUSTOMERSCHEDULE schedule)
        {
            var queryStr = "UPDATE TCUSTOMERSCHEDULE SET SCHNURSE = @SCHNURSE WHERE CUSTOMERID = @CUSTOMERID AND SCHEDULEID = @SCHEDULEID AND SCHEDULEID < 97175 AND SCHNURSE = 0 ";

            command.CommandText = queryStr;
            command.Parameters.Clear();

            command.Parameters.AddWithValue("@CUSTOMERID", schedule.CUSTOMERID);
            command.Parameters.AddWithValue("@SCHEDULEID", schedule.SCHEDULEID);
            command.Parameters.AddWithValue("@SCHNURSE", schedule.SCHNURSE);

            command.ExecuteNonQuery();

        }

        public void MigrateConsultScheduleMytPro()
        {
            int startRow = 0;
            int ppl = 1000;
            int count = 0;
            int uCnt = 0;
            int iCnt = 0;
            List<CUSTOMERSCHEDULE> consultList = null;
            try
            {
                while (true)
                {
                    consultList = mtpreader.ReadConsultSchedule(startRow * ppl, ppl);
                    startRow++;
                    if (consultList == null && consultList.Count == 0)
                    {
                        return;
                    }

                    var command = conn.CreateCommand();

                    foreach (var consult in consultList)
                    {
                        count++;
                        var queryStr1 = "SELECT CUSTOMERID FROM TCUSTOMERPERSONAL WHERE CUSTNAME = '" + consult.CUSTNAME + "' AND CUSTNO = '" + consult.CUSTNO + "' ";
                        command.CommandText = queryStr1;
                        var x1 = command.ExecuteScalar();
                        if (x1 != null)
                        {
                            consult.CUSTOMERID = x1.ToString();

                            var queryStr2 = "SELECT EMPLOYEEID FROM TEMPLOYEE WHERE EMPLNAME = '" + consult.SCHDOCTOR + "' AND EMPLTYPE = 2 ";
                            command.CommandText = queryStr2;
                            var x2 = command.ExecuteScalar();
                            if (x2 != null)
                            {
                                consult.SCHDOCTOR = x2.ToString();
                            }
                            else
                            {
                                consult.SCHDOCTOR = "0";
                            }
                            var queryStr3 = "SELECT EMPLOYEEID FROM TEMPLOYEE WHERE EMPLNAME = '" + consult.SCHNURSE + "' AND EMPLTYPE <> 2 ";
                            command.CommandText = queryStr3;
                            var x3 = command.ExecuteScalar();
                            if (x3 != null)
                            {
                                consult.SCHNURSE = x3.ToString();
                            }
                            else
                            {
                                consult.SCHNURSE = "0";
                            }

                            var queryStr4 = "SELECT SCHEDULEID FROM TCUSTOMERSCHEDULE WHERE RESVDATE = '" + consult.SCHEDULEDATE + "' AND CUSTOMERID = '" + consult.CUSTOMERID + "' ";
                            command.CommandText = queryStr4;
                            var x4 = command.ExecuteScalar();
                            if(x4 != null)
                            {
                                uCnt++;
                                consult.SCHEDULEID = x4.ToString();
                                updateConsultSchedule(command, consult);
                            } 
                            else
                            {
                                iCnt++;
                                InsertSchedule(command, consult);
                            }
                        }

                    }
                    Console.WriteLine("Update Count: " + uCnt + ", Insert Count: " + iCnt);
                    Console.WriteLine("Schedule count = {0}", count);
                    if (consultList.Count < ppl)
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        public void MigrateConsultScheduleMytProV1()
        {
            int startRow = 0;
            int ppl = 1000;
            int count = 0;
            List<CUSTOMERMEMO> consultList = null;
            CUSTOMERMEMO memo = new CUSTOMERMEMO();
            try
            {
                while (true)
                {
                    consultList = mtpreader.ReadConsultScheduleV1(startRow * ppl, ppl);
                    startRow++;
                    if (consultList == null && consultList.Count == 0)
                    {
                        return;
                    }

                    var command = conn.CreateCommand();

                    foreach (var consult in consultList)
                    {
                        count++;
                        var queryStr1 = "SELECT CUSTOMERID FROM TCUSTOMERPERSONAL WHERE CUSTNAME = '" + consult.CUSTNAME + "' AND CUSTNO = '" + consult.CUSTNO + "' ";
                        command.CommandText = queryStr1;
                        var x1 = command.ExecuteScalar();
                        if (x1 != null)
                        {
                            consult.CUSTOMERID = x1.ToString();

                           
                            if (consult.MEMO != "")
                            {
                                InsertCustomerMemo(command, consult);
                            }
                        }

                    }
                    Console.WriteLine("Schedule count = {0}", count);
                    if (consultList.Count < ppl)
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        public void MigratePaymentScheduleMytPro()
        {
            int startRow = 0;
            int ppl = 1000;
            int count = 0;
            List<PAYMENT> payList = null;
            CUSTOMERSCHEDULE schedule = new CUSTOMERSCHEDULE();
            try
            {
                while (true)
                {
                    payList = mtpreader.ReadPaymentSchedule(startRow * ppl, ppl);
                    startRow++;
                    if (payList == null && payList.Count == 0)
                    {
                        return;
                    }

                    var command = conn.CreateCommand();

                    foreach (var payment in payList)
                    {
                        count++;
                        SALESTATEMENT sales = new SALESTATEMENT();
                        var queryStr1 = "SELECT CUSTOMERID FROM TCUSTOMERPERSONAL WHERE CUSTNAME = '" + payment.CUSTNAME + "' AND CUSTNO = '" + payment.CUSTNO + "' ";
                        command.CommandText = queryStr1;
                        var x1 = command.ExecuteScalar();
                        if (x1 != null)
                        {
                            payment.CUSTOMERID = x1.ToString();

                            var queryStr2 = "SELECT SCHEDULEID FROM TCUSTOMERSCHEDULE WHERE CUSTOMERID = '" + payment.CUSTOMERID + "' AND (RESVDATE = '" + payment.PAYDATE + "' OR SCHEDULEDATE = '" + payment.PAYDATE + "') ";
                            command.CommandText = queryStr2;
                            var x2 = command.ExecuteScalar();
                            if (x2 != null)
                            {
                                payment.SCHEDULEID = x2.ToString();
                                UpdatepaymentSchedule(command, payment);
                            }
                            else
                            {
                                schedule = ConvertScheduleFromPayment(payment, schedule);
                                var schID2 = InsertSchedule(command, schedule);
                                payment.SCHEDULEID = schID2;
                            }
                            var queryStr3 = "SELECT STATEMENTID FROM TSALESTATEMENT WHERE SCHEDULEID = '" + payment.SCHEDULEID + "' AND CUSTOMERID = '" + payment.CUSTOMERID + "' ";
                            command.CommandText = queryStr3;
                            var x3 = command.ExecuteScalar();
                            if(x3 == null)
                            {
                                sales = ConvertSaleStatementFromPayment(payment, sales);
                                InsertSaleStatement(command, sales);
                            }
                            else if (payment.PAYMENTCODE == "R00" || payment.PAYMENTCODE == "R01" || payment.PAYMENTCODE == "R02" || payment.PAYMENTCODE == "R03")
                            {
                                sales = ConvertSaleStatementFromPayment(payment, sales);
                                sales.STATEMENTID = x3.ToString();
                                UpdateSaleStatement(command, sales);
                            }
                            //else if (payment.PAYMENTCODE != "R00" && payment.PAYMENTCODE != "R01" && payment.PAYMENTCODE != "R02" && payment.PAYMENTCODE != "R03")
                            //{
                            //    sales = ConvertSaleStatementFromPayment(payment, sales);
                            //    sales.STATEMENTID = x3.ToString();
                            //    UpdateSaleStatement(command, sales);
                            //}

                            InsertPayment(command, payment);
                        }

                    }
                    Console.WriteLine("Schedule count = {0}", count);
                    if (payList.Count < ppl)
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        public void MigrateCustomerPersonal()
        {
            int startRow = 0;
            int ppl = 1000;
            int count = 0;
            List<CUSTOMERPERSONAL> custList = null;
            CUSTOMERMEMO memo = new CUSTOMERMEMO();
            try
            {
                while (true)
                {
                    custList = reader.ReadCustomer(startRow * ppl, ppl);
                    startRow++;
                    if(custList == null && custList.Count == 0)
                    {
                        return;
                    }

                    var command = conn.CreateCommand();

                    foreach (var cust in custList)
                    {
                        count++;
                        cust.CUSTOMERID = InsertCustomer(command, cust);
                        if(cust.SCHMEMO1 != "")
                        {
                            memo = ConvertMemoFromCustomer(cust, memo, 1);
                            InsertCustomerMemo(command, memo);
                        }
                        if(cust.SCHMEMO4 != "")
                        {
                            memo = ConvertMemoFromCustomer(cust, memo, 4);
                            InsertCustomerMemo(command, memo);
                        }
                        if(cust.SCHMEMO00 != "")
                        {
                            memo = ConvertMemoFromCustomer(cust, memo, 10);
                            InsertCustomerMemo(command, memo);
                        }
                        if(cust.SCHMEMO01 != "")
                        {
                            memo = ConvertMemoFromCustomer(cust, memo, 11);
                            InsertCustomerMemo(command, memo);
                        }
                        if(cust.SCHMEMO02 != "")
                        {
                            memo = ConvertMemoFromCustomer(cust, memo, 12);
                            InsertCustomerMemo(command, memo);
                        }
                        if (cust.SCHMEMO40 != "")
                        {
                            memo = ConvertMemoFromCustomer(cust, memo, 40);
                            InsertCustomerMemo(command, memo);
                        }
                        if (cust.SCHMEMO41 != "")
                        {
                            memo = ConvertMemoFromCustomer(cust, memo, 41);
                            InsertCustomerMemo(command, memo);
                        }
                        if (cust.SCHMEMO42 != "")
                        {
                            memo = ConvertMemoFromCustomer(cust, memo, 42);
                            InsertCustomerMemo(command, memo);
                        }
                    }
                    Console.WriteLine("PatientPersonal count = {0}", count);
                    if (custList.Count < ppl)
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }

        private string InsertCustomer(MySqlCommand command, CUSTOMERPERSONAL cust)
        {
            var queryStr = "INSERT INTO TCUSTOMERPERSONAL (CUSTOMERID,ORGID,CUSTNAME,CUSTNO,CUSTJN,ENCRYPTEDJN,CUSTDOB,DOBTYPE,CUSTCELL1,CUSTCELL2,"
                         + "CUSTPHONE1,CUSTPHONE2,CUSTEMAIL,CUSTWEB,CUSTSVCAREA,CUSTTYPE,CUSTLVL,CUSTGENDER,CUSTJOB,CUSTPIC,CUSTREGDATE,CUSTFSTDATE,"
                         + "CUSTLSTDATE,CUSTZIPCODE1,CUSTADDR11,CUSTADDR12,CUSTZIPCODE2,CUSTADDR21,CUSTADDR22,CUSTZIPCODE3,CUSTADDR31,CUSTADDR32,DLIVADDR,"
                         + "CUSTNRID,CUSTDRID,RECVSMS,RECVEMAIL,CUSTNICKNAME,MARITAL,CUSTINTID,CUSTINTRE,CUSTINFX,CRTIME,DISCD,REFERRAL,CUSTMEMO,"
                         + "PERSONALINFO,EXMGMT,INTROMEMO,STATE1,FTTIME,FTFLAG,SURNAME,TITLE,ETHNICITY,ANNIVERSARY,INSTYPE,TXAGREE,POLICYAGREE,"
                         + "ARBTAGREE,RECVSMSDATE,RECVAD,NATION) "
                         + " VALUES (@CUSTOMERID,@ORGID,@CUSTNAME,@CUSTNO,@CUSTJN,@ENCRYPTEDJN,@CUSTDOB,@DOBTYPE,@CUSTCELL1,@CUSTCELL2,"
                         + "@CUSTPHONE1,@CUSTPHONE2,@CUSTEMAIL,@CUSTWEB,@CUSTSVCAREA,@CUSTTYPE,@CUSTLVL,@CUSTGENDER,@CUSTJOB,@CUSTPIC,@CUSTREGDATE,@CUSTFSTDATE,"
                         + "@CUSTLSTDATE,@CUSTZIPCODE1,@CUSTADDR11,@CUSTADDR12,@CUSTZIPCODE2,@CUSTADDR21,@CUSTADDR22,@CUSTZIPCODE3,@CUSTADDR31,@CUSTADDR32,@DLIVADDR,"
                         + "@CUSTNRID,@CUSTDRID,@RECVSMS,@RECVEMAIL,@CUSTNICKNAME,@MARITAL,@CUSTINTID,@CUSTINTRE,@CUSTINFX,@CRTIME,@DISCD,@REFERRAL,@CUSTMEMO,"
                         + "@PERSONALINFO,@EXMGMT,@INTROMEMO,@STATE1,@FTTIME,@FTFLAG,@SURNAME,@TITLE,@ETHNICITY,@ANNIVERSARY,@INSTYPE,@TXAGREE,@POLICYAGREE,"
                         + "@ARBTAGREE,@RECVSMSDATE,@RECVAD,@NATION)";

            command.CommandText = queryStr;
            command.Parameters.Clear();

            command.Parameters.AddWithValue("@CUSTOMERID", cust.CUSTOMERID);
            command.Parameters.AddWithValue("@ORGID", cust.ORGID);
            command.Parameters.AddWithValue("@CUSTNAME", cust.CUSTNAME);
            command.Parameters.AddWithValue("@CUSTNO", cust.CUSTNO);
            command.Parameters.AddWithValue("@CUSTJN", cust.CUSTJN);
            command.Parameters.AddWithValue("@ENCRYPTEDJN", cust.ENCRYPTEDJN);
            command.Parameters.AddWithValue("@CUSTDOB", cust.CUSTDOB);
            command.Parameters.AddWithValue("@DOBTYPE", cust.DOBTYPE);
            command.Parameters.AddWithValue("@CUSTCELL1", cust.CUSTCELL1);
            command.Parameters.AddWithValue("@CUSTCELL2", cust.CUSTCELL2);
            command.Parameters.AddWithValue("@CUSTPHONE1", cust.CUSTPHONE1);
            command.Parameters.AddWithValue("@CUSTPHONE2", cust.CUSTPHONE2);
            command.Parameters.AddWithValue("@CUSTEMAIL", cust.CUSTEMAIL);
            command.Parameters.AddWithValue("@CUSTWEB", cust.CUSTWEB);
            command.Parameters.AddWithValue("@CUSTSVCAREA", cust.CUSTSVCAREA);
            command.Parameters.AddWithValue("@CUSTTYPE", cust.CUSTTYPE);
            command.Parameters.AddWithValue("@CUSTLVL", cust.CUSTLVL);
            command.Parameters.AddWithValue("@CUSTGENDER", cust.CUSTGENDER);
            command.Parameters.AddWithValue("@CUSTJOB", cust.CUSTJOB);
            command.Parameters.AddWithValue("@CUSTPIC", cust.CUSTPIC);
            command.Parameters.AddWithValue("@CUSTREGDATE", cust.CUSTREGDATE);
            command.Parameters.AddWithValue("@CUSTFSTDATE", cust.CUSTFSTDATE);
            command.Parameters.AddWithValue("@CUSTLSTDATE", cust.CUSTLSTDATE);
            command.Parameters.AddWithValue("@CUSTZIPCODE1", cust.CUSTZIPCODE1);
            command.Parameters.AddWithValue("@CUSTADDR11", cust.CUSTADDR11);
            command.Parameters.AddWithValue("@CUSTADDR12", cust.CUSTADDR12);
            command.Parameters.AddWithValue("@CUSTZIPCODE2", cust.CUSTZIPCODE2);
            command.Parameters.AddWithValue("@CUSTADDR21", cust.CUSTADDR21);
            command.Parameters.AddWithValue("@CUSTADDR22", cust.CUSTADDR22);
            command.Parameters.AddWithValue("@CUSTZIPCODE3", cust.CUSTZIPCODE3);
            command.Parameters.AddWithValue("@CUSTADDR31", cust.CUSTADDR31);
            command.Parameters.AddWithValue("@CUSTADDR32", cust.CUSTADDR32);
            command.Parameters.AddWithValue("@DLIVADDR", cust.DLIVADDR);
            command.Parameters.AddWithValue("@CUSTNRID", cust.CUSTNRID);
            command.Parameters.AddWithValue("@CUSTDRID", cust.CUSTDRID);
            command.Parameters.AddWithValue("@RECVSMS", cust.RECVSMS);
            command.Parameters.AddWithValue("@RECVEMAIL", cust.RECVEMAIL);
            command.Parameters.AddWithValue("@CUSTNICKNAME", cust.CUSTNICKNAME);
            command.Parameters.AddWithValue("@MARITAL", cust.MARITAL);
            command.Parameters.AddWithValue("@CUSTINTID", cust.CUSTINTID);
            command.Parameters.AddWithValue("@CUSTINTRE", cust.CUSTINTRE);
            command.Parameters.AddWithValue("@CUSTINFX", cust.CUSTINFX);
            command.Parameters.AddWithValue("@CRTIME", cust.CRTIME);
            command.Parameters.AddWithValue("@DISCD", cust.DISCD);
            command.Parameters.AddWithValue("@REFERRAL", cust.REFERRAL);
            command.Parameters.AddWithValue("@CUSTMEMO", cust.CUSTMEMO);
            command.Parameters.AddWithValue("@PERSONALINFO", cust.PERSONALINFO);
            command.Parameters.AddWithValue("@EXMGMT", cust.EXMGMT);
            command.Parameters.AddWithValue("@INTROMEMO", cust.INTROMEMO);
            command.Parameters.AddWithValue("@STATE1", cust.STATE1);
            command.Parameters.AddWithValue("@FTTIME", cust.FTTIME);
            command.Parameters.AddWithValue("@FTFLAG", cust.FTFLAG);
            command.Parameters.AddWithValue("@SURNAME", cust.SURNAME);
            command.Parameters.AddWithValue("@TITLE", cust.TITLE);
            command.Parameters.AddWithValue("@ETHNICITY", cust.ETHNICITY);
            command.Parameters.AddWithValue("@ANNIVERSARY", cust.ANNIVERSARY);
            command.Parameters.AddWithValue("@INSTYPE", cust.INSTYPE);
            command.Parameters.AddWithValue("@TXAGREE", cust.TXAGREE);
            command.Parameters.AddWithValue("@POLICYAGREE", cust.POLICYAGREE);
            command.Parameters.AddWithValue("@ARBTAGREE", cust.ARBTAGREE);
            command.Parameters.AddWithValue("@RECVSMSDATE", cust.RECVSMSDATE);
            command.Parameters.AddWithValue("@RECVAD", cust.RECVAD);
            command.Parameters.AddWithValue("@NATION", cust.NATION);

            command.ExecuteNonQuery();
            string id = command.LastInsertedId.ToString();
            return id;
        }

        private string InsertSchedule(MySqlCommand command, CUSTOMERSCHEDULE schedule)
        {
            var queryStr = "INSERT INTO TCUSTOMERSCHEDULE (ORGID, CUSTOMERID, RESVTIME, RESVDATE, SCHEDULEDATE, SCHEDULETIME, SCHEDULESTATUS, SCHDOCTOR, SCHNURSE, PHYSICALEMPL, CONSULTTIME, SVCAREA, VISITTYPE, CONSULTNOTE, PROGRESSNOTE, RESVMEMO, NURSEMEMO, BOOKMARK, INSTYPE, DISCD, CRTIME, CONDITION1, CONDITION2, RESVCOUNT, RESVCFM, RESVTMO, RESVTDY, HISTMEMO, EXTRACOST, RESVEMPLID, EXRECALL, TRPLAN, ASSESSMENT, PAYMENTTYPE, MEDCOST, PREGNANT, MIG, NOCON, NOCALC, MODHIST, SUMMARY, TREATMENTROOM, SVCAREA2, REGTYPE, SCHTYPE) "
                         + " VALUES(@ORGID, @CUSTOMERID, @RESVTIME, @RESVDATE, @SCHEDULEDATE, @SCHEDULETIME, @SCHEDULESTATUS, @SCHDOCTOR, @SCHNURSE, @PHYSICALEMPL, @CONSULTTIME, @SVCAREA, @VISITTYPE, @CONSULTNOTE, @PROGRESSNOTE, @RESVMEMO, @NURSEMEMO, @BOOKMARK, @INSTYPE, @DISCD, @CRTIME, @CONDITION1, @CONDITION2, @RESVCOUNT, @RESVCFM, @RESVTMO, @RESVTDY, @HISTMEMO, @EXTRACOST, @RESVEMPLID, @EXRECALL, @TRPLAN, @ASSESSMENT, @PAYMENTTYPE, @MEDCOST, @PREGNANT, @MIG, @NOCON, @NOCALC, @MODHIST, @SUMMARY, @TREATMENTROOM, @SVCAREA2, @REGTYPE, @SCHTYPE);";

            command.CommandText = queryStr;
            command.Parameters.Clear();
            
            command.Parameters.AddWithValue("@ORGID", schedule.ORGID);
            command.Parameters.AddWithValue("@CUSTOMERID", schedule.CUSTOMERID);
            command.Parameters.AddWithValue("@RESVTIME", schedule.RESVTIME);
            command.Parameters.AddWithValue("@RESVDATE", schedule.RESVDATE);
            command.Parameters.AddWithValue("@SCHEDULEDATE", schedule.SCHEDULEDATE);
            command.Parameters.AddWithValue("@SCHEDULETIME", schedule.SCHEDULETIME);
            command.Parameters.AddWithValue("@SCHEDULESTATUS", schedule.SCHEDULESTATUS);
            command.Parameters.AddWithValue("@SCHDOCTOR", schedule.SCHDOCTOR);
            command.Parameters.AddWithValue("@SCHNURSE", schedule.SCHNURSE);
            command.Parameters.AddWithValue("@PHYSICALEMPL", schedule.PHYSICALEMPL);
            command.Parameters.AddWithValue("@CONSULTTIME", schedule.CONSULTTIME);
            command.Parameters.AddWithValue("@SVCAREA", schedule.SVCAREA);
            command.Parameters.AddWithValue("@VISITTYPE", schedule.VISITTYPE);
            command.Parameters.AddWithValue("@CONSULTNOTE", schedule.CONSULTNOTE);
            command.Parameters.AddWithValue("@PROGRESSNOTE", schedule.PROGRESSNOTE);
            command.Parameters.AddWithValue("@RESVMEMO", schedule.RESVMEMO);
            command.Parameters.AddWithValue("@NURSEMEMO", schedule.NURSEMEMO);
            command.Parameters.AddWithValue("@BOOKMARK", schedule.BOOKMARK);
            command.Parameters.AddWithValue("@INSTYPE", schedule.INSTYPE);
            command.Parameters.AddWithValue("@DISCD", schedule.DISCD);
            command.Parameters.AddWithValue("@CRTIME", schedule.CRTIME);
            command.Parameters.AddWithValue("@CONDITION1", schedule.CONDITION1);
            command.Parameters.AddWithValue("@CONDITION2", schedule.CONDITION2);
            command.Parameters.AddWithValue("@RESVCOUNT", schedule.RESVCOUNT);
            command.Parameters.AddWithValue("@RESVCFM", schedule.RESVCFM);
            command.Parameters.AddWithValue("@RESVTMO", schedule.RESVTMO);
            command.Parameters.AddWithValue("@RESVTDY", schedule.RESVTDY);
            command.Parameters.AddWithValue("@HISTMEMO", schedule.HISTMEMO);
            command.Parameters.AddWithValue("@EXTRACOST", schedule.EXTRACOST);
            command.Parameters.AddWithValue("@RESVEMPLID", schedule.RESVEMPLID);
            command.Parameters.AddWithValue("@EXRECALL", schedule.EXRECALL);
            command.Parameters.AddWithValue("@TRPLAN", schedule.TRPLAN);
            command.Parameters.AddWithValue("@ASSESSMENT", schedule.ASSESSMENT);
            command.Parameters.AddWithValue("@PAYMENTTYPE", schedule.PAYMENTTYPE);
            command.Parameters.AddWithValue("@MEDCOST", schedule.MEDCOST);
            command.Parameters.AddWithValue("@PREGNANT", schedule.PREGNANT);
            command.Parameters.AddWithValue("@MIG", schedule.MIG);
            command.Parameters.AddWithValue("@NOCON", schedule.NOCON);
            command.Parameters.AddWithValue("@NOCALC", schedule.NOCALC);
            command.Parameters.AddWithValue("@MODHIST", schedule.MODHIST);
            command.Parameters.AddWithValue("@SUMMARY", schedule.SUMMARY);
            command.Parameters.AddWithValue("@TREATMENTROOM", schedule.TREATMENTROOM);
            command.Parameters.AddWithValue("@SVCAREA2", schedule.SVCAREA2);
            command.Parameters.AddWithValue("@REGTYPE", schedule.REGTYPE);
            command.Parameters.AddWithValue("@SCHTYPE", schedule.SCHTYPE);


            command.ExecuteNonQuery();
            string id = command.LastInsertedId.ToString();
            return id;
        }

        private string InsertCustomerMemo(MySqlCommand command, CUSTOMERMEMO cust)
        {
            var queryStr = "INSERT INTO TCUSTOMERMEMO (ORGID, USERID, EMPLNAME, CUSTOMERID, MEMO, MEMODATE, MEMOTYPE, DISCD, CALLTYPE, CRTIME, SCHEDULEID, TOP, EMPLOYEEID, MODTIME, COLOR) VALUES "
                         + "(@ORGID, @USERID, @EMPLNAME, @CUSTOMERID, @MEMO, @MEMODATE, @MEMOTYPE, @DISCD, @CALLTYPE, @CRTIME, @SCHEDULEID, @TOP, @EMPLOYEEID, @MODTIME, @COLOR); ";

            command.CommandText = queryStr;
            command.Parameters.Clear();

            command.Parameters.AddWithValue("@CUSTOMERID", cust.CUSTOMERID);
            command.Parameters.AddWithValue("@ORGID", cust.ORGID);
            command.Parameters.AddWithValue("@USERID", cust.USERID);
            command.Parameters.AddWithValue("@EMPLNAME", cust.EMPLNAME);
            command.Parameters.AddWithValue("@MEMO", cust.MEMO);
            command.Parameters.AddWithValue("@MEMODATE", cust.MEMODATE);
            command.Parameters.AddWithValue("@MEMOTYPE", cust.MEMOTYPE);
            command.Parameters.AddWithValue("@DISCD", cust.DISCD);
            command.Parameters.AddWithValue("@CALLTYPE", cust.CALLTYPE);
            command.Parameters.AddWithValue("@CRTIME", cust.CRTIME);
            command.Parameters.AddWithValue("@SCHEDULEID", cust.SCHEDULEID);
            command.Parameters.AddWithValue("@TOP", cust.TOP);
            command.Parameters.AddWithValue("@EMPLOYEEID", cust.EMPLOYEEID);
            command.Parameters.AddWithValue("@MODTIME", cust.MODTIME);
            command.Parameters.AddWithValue("@COLOR", cust.COLOR);

            command.ExecuteNonQuery();
            string id = command.LastInsertedId.ToString();
            return id;
        }

        //InsertSaleStatement
        private string InsertSaleStatement(MySqlCommand command, SALESTATEMENT sales)
        {
            var queryStr = "INSERT INTO TSALESTATEMENT (SCHEDULEID, CUSTOMERID, LIABILITYAMT, CLAIMAMT, AIDAMT1, AIDAMT2, NONINSAMT, DISCOUNTAMT, CARINSAMT, LOSSAMT, DISCD, CRTIME, ORGID, INS100AMT, LTCLAIMAMT, LTCHARGEAMT, TAXABLEAMT, REFUNDAMT, TAXDCAMT) "
                         + " VALUES (@SCHEDULEID, @CUSTOMERID, @LIABILITYAMT, @CLAIMAMT, @AIDAMT1, @AIDAMT2, @NONINSAMT, @DISCOUNTAMT, @CARINSAMT, @LOSSAMT, @DISCD, @CRTIME, @ORGID, @INS100AMT, @LTCLAIMAMT, @LTCHARGEAMT, @TAXABLEAMT, @REFUNDAMT, @TAXDCAMT); ";

            command.CommandText = queryStr;
            command.Parameters.Clear();

            command.Parameters.AddWithValue("@SCHEDULEID", sales.SCHEDULEID);
            command.Parameters.AddWithValue("@CUSTOMERID", sales.CUSTOMERID);
            command.Parameters.AddWithValue("@LIABILITYAMT", sales.LIABILITYAMT);
            command.Parameters.AddWithValue("@CLAIMAMT", sales.CLAIMAMT);
            command.Parameters.AddWithValue("@AIDAMT1", sales.AIDAMT1);
            command.Parameters.AddWithValue("@AIDAMT2", sales.AIDAMT2);
            command.Parameters.AddWithValue("@NONINSAMT", sales.NONINSAMT);
            command.Parameters.AddWithValue("@DISCOUNTAMT", sales.DISCOUNTAMT);
            command.Parameters.AddWithValue("@CARINSAMT", sales.CARINSAMT);
            command.Parameters.AddWithValue("@LOSSAMT", sales.LOSSAMT);
            command.Parameters.AddWithValue("@DISCD", sales.DISCD);
            command.Parameters.AddWithValue("@CRTIME", sales.CRTIME);
            command.Parameters.AddWithValue("@ORGID", sales.ORGID);
            command.Parameters.AddWithValue("@INS100AMT", sales.INS100AMT);
            command.Parameters.AddWithValue("@LTCLAIMAMT", sales.LTCLAIMAMT);
            command.Parameters.AddWithValue("@LTCHARGEAMT", sales.LTCHARGEAMT);
            command.Parameters.AddWithValue("@TAXABLEAMT", sales.TAXABLEAMT);
            command.Parameters.AddWithValue("@REFUNDAMT", sales.REFUNDAMT);
            command.Parameters.AddWithValue("@TAXDCAMT", sales.TAXDCAMT);

            command.ExecuteNonQuery();
            string id = command.LastInsertedId.ToString();
            return id;
        }

        private void UpdateSaleStatement(MySqlCommand command, SALESTATEMENT sales)
        {
            //var queryStr = "UPDATE TSALESTATEMENT SET NONINSAMT = NONINSAMT + @NONINSAMT, TAXABLEAMT = TAXABLEAMT + @TAXABLEAMT  WHERE SCHEDULEID = @SCHEDULEID AND CUSTOMERID = @CUSTOMERID AND STATEMENTID = @STATEMENTID ";
            var queryStr = "UPDATE TSALESTATEMENT SET REFUNDAMT = @REFUNDAMT  WHERE SCHEDULEID = @SCHEDULEID AND CUSTOMERID = @CUSTOMERID AND STATEMENTID = @STATEMENTID ";
            command.CommandText = queryStr;

            command.Parameters.Clear();
            command.Parameters.AddWithValue("@STATEMENTID", sales.STATEMENTID);
            command.Parameters.AddWithValue("@SCHEDULEID", sales.SCHEDULEID);
            command.Parameters.AddWithValue("@CUSTOMERID", sales.CUSTOMERID);
            command.Parameters.AddWithValue("@REFUNDAMT", sales.REFUNDAMT);
            //command.Parameters.AddWithValue("@NONINSAMT", sales.NONINSAMT);
            //command.Parameters.AddWithValue("@TAXABLEAMT", sales.TAXABLEAMT);
            command.ExecuteNonQuery();
        }

        // InsertPayment
        private string InsertPayment(MySqlCommand command, PAYMENT payment)
        {
            var queryStr = "INSERT INTO TPAYMENT (ORGID, CUSTOMERID, SCHEDULEID, PAYMENTAMT, PAYLIABILITYAMT, PAYMENTCODE, RECEIPTISSUE, BILLISSUE, EMPLOYEEID, PAYNAME, DESCRIPTION, REFUNDFLAG, PAYDATE, MODTIME, ORDERDATE, FINALDATE, FINALUNPAID, PAYCALFLAG, CRTIME, CASHRECEIPTID, CRISSUED, DISCD, TAX) "
                         + " VALUES(@ORGID, @CUSTOMERID, @SCHEDULEID, @PAYMENTAMT, @PAYLIABILITYAMT, @PAYMENTCODE, @RECEIPTISSUE, @BILLISSUE, @EMPLOYEEID, @PAYNAME, @DESCRIPTION, @REFUNDFLAG, @PAYDATE, @MODTIME, @ORDERDATE, @FINALDATE, @FINALUNPAID, @PAYCALFLAG, @CRTIME, @CASHRECEIPTID, @CRISSUED, @DISCD, @TAX);";

            command.CommandText = queryStr;
            command.Parameters.Clear();

            command.Parameters.AddWithValue("@ORGID", payment.ORGID);
            command.Parameters.AddWithValue("@CUSTOMERID", payment.CUSTOMERID);
            command.Parameters.AddWithValue("@SCHEDULEID", payment.SCHEDULEID);
            command.Parameters.AddWithValue("@PAYMENTAMT", payment.PAYMENTAMT);
            command.Parameters.AddWithValue("@PAYLIABILITYAMT", payment.PAYLIABILITYAMT);
            command.Parameters.AddWithValue("@PAYMENTCODE", payment.PAYMENTCODE);
            command.Parameters.AddWithValue("@RECEIPTISSUE", payment.RECEIPTISSUE);
            command.Parameters.AddWithValue("@BILLISSUE", payment.BILLISSUE);
            command.Parameters.AddWithValue("@EMPLOYEEID", payment.EMPLOYEEID);
            command.Parameters.AddWithValue("@PAYNAME", payment.PAYNAME);
            command.Parameters.AddWithValue("@DESCRIPTION", payment.DESCRIPTION);
            command.Parameters.AddWithValue("@REFUNDFLAG", payment.REFUNDFLAG);
            command.Parameters.AddWithValue("@PAYDATE", payment.PAYDATE);
            command.Parameters.AddWithValue("@MODTIME", payment.MODTIME);
            command.Parameters.AddWithValue("@ORDERDATE", payment.ORDERDATE);
            command.Parameters.AddWithValue("@FINALDATE", payment.FINALDATE);
            command.Parameters.AddWithValue("@FINALUNPAID", payment.FINALUNPAID);
            command.Parameters.AddWithValue("@PAYCALFLAG", payment.PAYCALFLAG);
            command.Parameters.AddWithValue("@CRTIME", payment.CRTIME);
            command.Parameters.AddWithValue("@CASHRECEIPTID", payment.CASHRECEIPTID);
            command.Parameters.AddWithValue("@CRISSUED", payment.CRISSUED);
            command.Parameters.AddWithValue("@DISCD", payment.DISCD);
            command.Parameters.AddWithValue("@TAX", payment.TAX);

            command.ExecuteNonQuery();
            string id = command.LastInsertedId.ToString();
            return id;
        }
        
        private void updateConsultSchedule(MySqlCommand command, CUSTOMERSCHEDULE schedule)
        {
            var queryStr = "UPDATE TCUSTOMERSCHEDULE SET CONSULTNOTE = @CONSULTNOTE, PROGRESSNOTE = @PROGRESSNOTE, SCHEDULESTATUS = @SCHEDULESTATUS, SCHEDULEDATE = RESVDATE, SCHEDULETIME = RESVTIME, CONSULTTIME = CONCAT(RESVDATE, RESVTIME)  "
                         + " WHERE CUSTOMERID = @CUSTOMERID AND RESVDATE = @RESVDATE AND SCHEDULEID = @SCHEDULEID";

            command.CommandText = queryStr;
            command.Parameters.Clear();

            command.Parameters.AddWithValue("@CUSTOMERID", schedule.CUSTOMERID);
            command.Parameters.AddWithValue("@SCHEDULEID", schedule.SCHEDULEID);
            command.Parameters.AddWithValue("@CONSULTNOTE", schedule.CONSULTNOTE);
            command.Parameters.AddWithValue("@PROGRESSNOTE", schedule.PROGRESSNOTE);
            command.Parameters.AddWithValue("@RESVDATE", schedule.SCHEDULEDATE);

            command.Parameters.AddWithValue("@SCHEDULESTATUS", "2");

            command.ExecuteNonQuery();
        }
        private void UpdatepaymentSchedule(MySqlCommand command, PAYMENT payment)
        {
            //var queryStr = "UPDATE TCUSTOMERSCHEDULE SET CONSULTNOTE = @CONSULTNOTE, SCHEDULESTATUS = @SCHEDULESTATUS, SCHEDULEDATE = RESVDATE, SCHEDULETIME = RESVTIME, CONSULTTIME = CONCAT(RESVDATE, RESVTIME), MEDCOST = MEDCOST + @MEDCOST  "
            //             + " WHERE CUSTOMERID = @CUSTOMERID AND RESVDATE = @RESVDATE AND SCHEDULEID = @SCHEDULEID";
            var queryStr = "UPDATE TCUSTOMERSCHEDULE SET ASSESSMENT = @ASSESSMENT, SCHEDULESTATUS = @SCHEDULESTATUS, SCHEDULEDATE = RESVDATE, SCHEDULETIME = RESVTIME, CONSULTTIME = CONCAT(RESVDATE, RESVTIME), MEDCOST = MEDCOST + @MEDCOST  "
                         + " WHERE CUSTOMERID = @CUSTOMERID AND RESVDATE = @RESVDATE AND SCHEDULEID = @SCHEDULEID";

            command.CommandText = queryStr;
            command.Parameters.Clear();
            
            command.Parameters.AddWithValue("@CUSTOMERID", payment.CUSTOMERID);
            command.Parameters.AddWithValue("@SCHEDULEID", payment.SCHEDULEID);

            var medcost = 0;
            if (payment.PAYMENTCODE == "R01" || payment.PAYMENTCODE == "R00" || payment.PAYMENTCODE == "R02" || payment.PAYMENTCODE == "R03")
            {
                medcost = 0;
            } else
            {
                medcost = int.Parse(payment.PAYMENTAMT);
            }
            command.Parameters.AddWithValue("@MEDCOST", medcost);
            command.Parameters.AddWithValue("@RESVDATE", payment.PAYDATE);
            //command.Parameters.AddWithValue("@CONSULTNOTE", payment.CONSULTNOTE);
            command.Parameters.AddWithValue("@ASSESSMENT", payment.ASSESSMENT);
            command.Parameters.AddWithValue("@SCHEDULESTATUS", "7");
            
            command.ExecuteNonQuery();
        }

        public CUSTOMERMEMO ConvertMemoFromCustomer(CUSTOMERPERSONAL customer, CUSTOMERMEMO memo, int type)
        {
            memo = new CUSTOMERMEMO();
            memo.ORGID = customer.ORGID;
            memo.CUSTOMERID = customer.CUSTOMERID;
            memo.MEMODATE = customer.CUSTFSTDATE; // Check.. 
            if(type == 1)
            {
                memo.MEMO = customer.SCHMEMO1;
                memo.MEMOTYPE = "1";
            } else if(type == 4)
            {
                memo.MEMO = customer.SCHMEMO4;
                memo.MEMOTYPE = "4";
            } else if(type == 10)
            {
                memo.MEMO = customer.SCHMEMO00;
                memo.MEMOTYPE = "0";
            } else if(type == 11)
            {
                memo.MEMO = customer.SCHMEMO01;
                memo.MEMOTYPE = "0";
            } else if(type == 12)
            {
                memo.MEMO = customer.SCHMEMO02;
                memo.MEMOTYPE = "0";
            } else if(type == 40)
            {
                memo.MEMO = customer.SCHMEMO40;
                memo.MEMOTYPE = "4";
            } else if(type == 41)
            {
                memo.MEMO = customer.SCHMEMO41;
                memo.MEMOTYPE = "4";
            } else if(type == 42)
            {
                memo.MEMO = customer.SCHMEMO42;
                memo.MEMOTYPE = "4";
            }

            memo.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
            return memo;
        }

        public CUSTOMERMEMO ConvertMemoFromSchedule(CUSTOMERSCHEDULE schedule, CUSTOMERMEMO memo, int status)
        {
            memo = new CUSTOMERMEMO();
            memo.ORGID = schedule.ORGID;
            memo.CUSTOMERID = schedule.CUSTOMERID;
            
            if (status == 1)
            {
                memo.MEMODATE = schedule.RESVDATE;
                memo.MEMO = "[예약/접수메모]\n" + schedule.RESVMEMO + "\n(예약: " + Format_stdate(schedule.RESVDATE) +" " + Format_sttime(schedule.RESVTIME) + ")";
                memo.MEMOTYPE = "2"; // resvMemo -> type : 2
                memo.SCHEDULEID = schedule.SCHEDULEID;
                memo.EMPLNAME = schedule.RECPNAME;
                memo.USERID = schedule.RECPNAME;
            }

            memo.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
            return memo;
        }
        
        public CUSTOMERSCHEDULE ConvertScheduleFromPayment(PAYMENT payment, CUSTOMERSCHEDULE schedule)
        {
            schedule = new CUSTOMERSCHEDULE();
            schedule.ORGID = payment.ORGID;
            //schedule.CONSULTNOTE = payment.CONSULTNOTE;
            schedule.ASSESSMENT = payment.ASSESSMENT;

            schedule.CUSTOMERID = payment.CUSTOMERID;
            schedule.SCHEDULEDATE = payment.PAYDATE;
            var medcost = 0;
            if (payment.PAYMENTCODE == "R01" || payment.PAYMENTCODE == "R00" || payment.PAYMENTCODE == "R02" || payment.PAYMENTCODE == "R03")
            {
                medcost = 0;
            }
            else
            {
                medcost = int.Parse(payment.PAYMENTAMT);
            }
            schedule.MEDCOST = medcost.ToString();

            schedule.MIG = "1";
            schedule.SCHEDULETIME = "180000";
            schedule.INSTYPE = "2";

            schedule.SCHDOCTOR = "0";
            schedule.SCHNURSE = "0";
            schedule.SVCAREA = "0";
            schedule.VISITTYPE = "0";
            schedule.CONSULTTIME = schedule.SCHEDULEDATE + schedule.SCHEDULETIME;

            schedule.SCHEDULESTATUS = "7";
            schedule.CRTIME = payment.CRTIME;
            
            return schedule;
        }

        public SALESTATEMENT ConvertSaleStatementFromPayment(PAYMENT payment, SALESTATEMENT sales)
        {
            sales = new SALESTATEMENT();
            sales.ORGID = payment.ORGID;
            sales.NONINSAMT = payment.TOTALPRICE;
            var tax = int.Parse(sales.NONINSAMT) / 11;
            sales.TAXABLEAMT = (int.Parse(sales.NONINSAMT) - tax).ToString();
            sales.SCHEDULEID = payment.SCHEDULEID;
            sales.CUSTOMERID = payment.CUSTOMERID;

            if (payment.PAYMENTCODE == "R00" || payment.PAYMENTCODE == "R01" || payment.PAYMENTCODE == "R02" || payment.PAYMENTCODE == "R03")
            {
                sales.REFUNDAMT = payment.PAYMENTAMT;
            }
            sales.CRTIME = payment.CRTIME;

            return sales;
        }

        public string Format_stdate(string date)
        {
            if (date == null) return "";
            if (date == "") return "";

            
            return date.Substring(0, 4) + "-" + date.Substring(4, 2) + "-" + date.Substring(6, 2);
        }

        public string Format_sttime(string time)
        {
            if (time == null) return "";
            if (time == "") return "";
            
            if(time.Length < 4)
            {
                Console.WriteLine("Format_sttime :: " + time);
                time = "0" + time;
                Console.WriteLine("CHANGE Format_sttime :: " + time + "\n\n\n");
            }
            return time.Substring(0, 2) + ":" + time.Substring(2, 2);
        }

    }
}