﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HanchartDatabase
{
    public class CUSTOMERPERSONAL
    {
        public string CUSTOMERID { get; set; }
        public string ORGID { get; set; }
        public string CUSTNAME { get; set; }
        public string CUSTNO { get; set; }
        public string CUSTJN { get; set; }
        public string ENCRYPTEDJN { get; set; }
        public string CUSTDOB { get; set; }
        public string DOBTYPE { get; set; }
        public string CUSTCELL1 { get; set; }
        public string CUSTCELL2 { get; set; }
        public string CUSTPHONE1 { get; set; }
        public string CUSTPHONE2 { get; set; }
        public string CUSTEMAIL { get; set; }
        public string CUSTWEB { get; set; }
        public string CUSTSVCAREA { get; set; }
        public string CUSTTYPE { get; set; }
        public string CUSTLVL { get; set; }
        public string CUSTGENDER { get; set; }
        public string CUSTJOB { get; set; }
        public string CUSTPIC { get; set; }
        public string CUSTREGDATE { get; set; }
        public string CUSTFSTDATE { get; set; }
        public string CUSTLSTDATE { get; set; }
        public string CUSTZIPCODE1 { get; set; }
        public string CUSTADDR11 { get; set; }
        public string CUSTADDR12 { get; set; }
        public string CUSTZIPCODE2 { get; set; }
        public string CUSTADDR21 { get; set; }
        public string CUSTADDR22 { get; set; }
        public string CUSTZIPCODE3 { get; set; }
        public string CUSTADDR31 { get; set; }
        public string CUSTADDR32 { get; set; }
        public string DLIVADDR { get; set; }
        public string CUSTNRID { get; set; }
        public string CUSTDRID { get; set; }
        public string RECVSMS { get; set; }
        public string RECVEMAIL { get; set; }
        public string CUSTNICKNAME { get; set; }
        public string MARITAL { get; set; }
        public string CUSTINTID { get; set; }
        public string CUSTINTRE { get; set; }
        public string CUSTINFX { get; set; }
        public string CRTIME { get; set; }
        public string DISCD { get; set; }
        public string REFERRAL { get; set; }
        public string CUSTMEMO { get; set; }
        public string PERSONALINFO { get; set; }
        public string EXMGMT { get; set; }
        public string INTROMEMO { get; set; }
        public string STATE1 { get; set; }
        public string FTTIME { get; set; }
        public string FTFLAG { get; set; }
        public string SURNAME { get; set; }
        public string TITLE { get; set; }
        public string ETHNICITY { get; set; }
        public string ANNIVERSARY { get; set; }
        public string INSTYPE { get; set; }
        public string TXAGREE { get; set; }
        public string POLICYAGREE { get; set; }
        public string ARBTAGREE { get; set; }
        public string RECVSMSDATE { get; set; }
        public string RECVAD { get; set; }
        public string NATION { get; set; }
        public string SCHMEMO00 { get; set; }
        public string SCHMEMO01 { get; set; }
        public string SCHMEMO02 { get; set; }
        public string SCHMEMO1 { get; set; }
        public string SCHMEMO4 { get; set; }
        public string SCHMEMO40 { get; set; }
        public string SCHMEMO41 { get; set; }
        public string SCHMEMO42 { get; set; }

        public CUSTOMERPERSONAL()
        {
            CUSTOMERID = "0";
            ORGID = "0";
            CUSTNAME = "";
            CUSTNO = "";
            CUSTJN = "";
            ENCRYPTEDJN = "";
            CUSTDOB = "";
            DOBTYPE = "0";
            CUSTCELL1 = "";
            CUSTCELL2 = "";
            CUSTPHONE1 = "";
            CUSTPHONE2 = "";
            CUSTEMAIL = "";
            CUSTWEB = "";
            CUSTSVCAREA = "";
            CUSTTYPE = "";
            CUSTLVL = "";
            CUSTGENDER = "0";
            CUSTJOB = "";
            CUSTPIC = "";
            CUSTREGDATE = "";
            CUSTFSTDATE = "";
            CUSTLSTDATE = "";
            CUSTZIPCODE1 = "";
            CUSTADDR11 = "";
            CUSTADDR12 = "";
            CUSTZIPCODE2 = "";
            CUSTADDR21 = "";
            CUSTADDR22 = "";
            CUSTZIPCODE3 = "";
            CUSTADDR31 = "";
            CUSTADDR32 = "";
            DLIVADDR = "0";
            CUSTNRID = "0";
            CUSTDRID = "0";
            RECVSMS = "0";
            RECVEMAIL = "0";
            CUSTNICKNAME = "";
            MARITAL = "0";
            CUSTINTID = "0";
            CUSTINTRE = "";
            CUSTINFX = "";
            CRTIME = "";
            DISCD = "0";
            REFERRAL = "0";
            CUSTMEMO = "";
            PERSONALINFO = "0";
            EXMGMT = "0";
            INTROMEMO = "";
            STATE1 = "";
            FTTIME = "0";
            FTFLAG = "0";
            SURNAME = "";
            TITLE = "";
            ETHNICITY = "";
            ANNIVERSARY = "";
            INSTYPE = "";
            TXAGREE = "0";
            POLICYAGREE = "0";
            ARBTAGREE = "0";
            RECVSMSDATE = "";
            RECVAD = "0";
            NATION = "";
            SCHMEMO00 = "";
            SCHMEMO01 = "";
            SCHMEMO02 = "";
            SCHMEMO1 = "";
            SCHMEMO4 = "";
            SCHMEMO40 = "";
            SCHMEMO41 = "";
            SCHMEMO42 = "";
        }   
    }

    public class CUSTOMERSCHEDULE
    {
        public string SCHEDULEID { get; set; }
        public string ORGID { get; set; }
        public string CUSTOMERID { get; set; }
        public string RESVTIME { get; set; }
        public string RESVDATE { get; set; }
        public string SCHEDULEDATE { get; set; }
        public string SCHEDULETIME { get; set; }
        public string SCHEDULESTATUS { get; set; }
        public string SCHDOCTOR { get; set; }
        public string SCHNURSE { get; set; }
        public string PHYSICALEMPL { get; set; }
        public string CONSULTTIME { get; set; }
        public string SVCAREA { get; set; }
        public string VISITTYPE { get; set; }
        public string CONSULTNOTE { get; set; }
        public string PROGRESSNOTE { get; set; }
        public string RESVMEMO { get; set; }
        public string NURSEMEMO { get; set; }
        public string BOOKMARK { get; set; }
        public string INSTYPE { get; set; }
        public string DISCD { get; set; }
        public string CRTIME { get; set; }
        public string CONDITION1 { get; set; }
        public string CONDITION2 { get; set; }
        public string RESVCOUNT { get; set; }
        public string RESVCFM { get; set; }
        public string RESVTMO { get; set; }
        public string RESVTDY { get; set; }
        public string HISTMEMO { get; set; }
        public string EXTRACOST { get; set; }
        public string RESVEMPLID { get; set; }
        public string EXRECALL { get; set; }
        public string TRPLAN { get; set; }
        public string ASSESSMENT { get; set; }
        public string PAYMENTTYPE { get; set; }
        public string MEDCOST { get; set; }
        public string PREGNANT { get; set; }
        public string MIG { get; set; }
        public string NOCON { get; set; }
        public string NOCALC { get; set; }
        public string MODHIST { get; set; }
        public string SUMMARY { get; set; }
        public string TREATMENTROOM { get; set; }
        public string SVCAREA2 { get; set; }
        public string REGTYPE { get; set; }
        public string SCHTYPE { get; set; }

        public string CUSTNO { get; set; }
        public string CUSTNAME { get; set; }
        public string RECPNAME { get; set; }


        public CUSTOMERSCHEDULE ()
        {
            SCHEDULEID = "";
            ORGID = "0";
            CUSTOMERID = "0";
            RESVTIME = "";
            RESVDATE = "";
            SCHEDULEDATE = "";
            SCHEDULETIME = "";
            SCHEDULESTATUS = "0";
            SCHDOCTOR = "";
            SCHNURSE = "";
            PHYSICALEMPL = "";
            CONSULTTIME = "";
            SVCAREA = "";
            VISITTYPE = "";
            CONSULTNOTE = "";
            PROGRESSNOTE = "";
            RESVMEMO = "";
            NURSEMEMO = "";
            BOOKMARK = "0";
            INSTYPE = "0";
            DISCD = "0";
            CRTIME = "";
            CONDITION1 = "0";
            CONDITION2 = "0";
            RESVCOUNT = "";
            RESVCFM = "0";
            RESVTMO = "0";
            RESVTDY = "0";
            HISTMEMO = "";
            EXTRACOST = "0";
            RESVEMPLID = "0";
            EXRECALL = "0";
            TRPLAN = "";
            ASSESSMENT = "";
            PAYMENTTYPE = "";
            MEDCOST = "0";
            PREGNANT = "";
            MIG = "0";
            NOCON = "0";
            NOCALC = "";
            MODHIST = "";
            SUMMARY = "";
            TREATMENTROOM = "0";
            SVCAREA2 = "0";
            REGTYPE = "0";
            SCHTYPE = "0";

            CUSTNO = "";
            CUSTNAME = "";
            RECPNAME = "";
        }
    }

    public class SALESTATEMENT
    {
        public string STATEMENTID { get; set; }
        public string SCHEDULEID { get; set; }
        public string CUSTOMERID { get; set; }
        public string LIABILITYAMT { get; set; }
        public string CLAIMAMT { get; set; }
        public string AIDAMT1 { get; set; }
        public string AIDAMT2 { get; set; }
        public string NONINSAMT { get; set; }
        public string DISCOUNTAMT { get; set; }
        public string CARINSAMT { get; set; }
        public string LOSSAMT { get; set; }
        public string DISCD { get; set; }
        public string CRTIME { get; set; }
        public string ORGID { get; set; }
        public string INS100AMT { get; set; }
        public string LTCLAIMAMT { get; set; }
        public string LTCHARGEAMT { get; set; }
        public string TAXABLEAMT { get; set; }
        public string REFUNDAMT { get; set; }
        public string TAXDCAMT { get; set; }

        public SALESTATEMENT()
        {
            STATEMENTID = "";
            SCHEDULEID = "";
            CUSTOMERID = "";
            LIABILITYAMT = "0";
            CLAIMAMT = "0";
            AIDAMT1 = "0";
            AIDAMT2 = "0";
            NONINSAMT = "0";
            DISCOUNTAMT = "0";
            CARINSAMT = "0";
            LOSSAMT = "0";
            DISCD = "0";
            CRTIME = "";
            ORGID = "0";
            INS100AMT = "";
            LTCLAIMAMT = "";
            LTCHARGEAMT = "";
            TAXABLEAMT = "0";
            REFUNDAMT = "0";
            TAXDCAMT = "0";
        }
    }

    public class PAYMENT
    {
        public string PAYMENTID { get; set; }
        public string ORGID { get; set; }
        public string CUSTOMERID { get; set; }
        public string SCHEDULEID { get; set; }
        public string PAYMENTAMT { get; set; }
        public string PAYLIABILITYAMT { get; set; }
        public string PAYMENTCODE { get; set; }
        public string RECEIPTISSUE { get; set; }
        public string BILLISSUE { get; set; }
        public string EMPLOYEEID { get; set; }
        public string PAYNAME { get; set; }
        public string DESCRIPTION { get; set; }
        public string REFUNDFLAG { get; set; }
        public string PAYDATE { get; set; }
        public string ORDERDATE { get; set; }
        public string FINALDATE { get; set; }
        public string FINALUNPAID { get; set; }
        public string PAYCALFLAG { get; set; }
        public string CRTIME { get; set; }
        public string CASHRECEIPTID { get; set; }
        public string CRISSUED { get; set; }
        public string DISCD { get; set; }
        public string TAX { get; set; }
        public string MODTIME { get; set; }
        public string CUSTNAME { get; set; }
        public string CUSTNO { get; set; }
        public string CONSULTNOTE { get; set; }
        public string TOTALPRICE { get; set; }
        public string ASSESSMENT { get; set; }

        public PAYMENT()
        {
            PAYMENTID = "";
            ORGID = "";
            CUSTOMERID = "0";
            SCHEDULEID = "";
            PAYMENTAMT = "0";
            PAYLIABILITYAMT = "0";
            PAYMENTCODE = "";
            RECEIPTISSUE = "0";
            BILLISSUE = "0";
            EMPLOYEEID = "";
            PAYNAME = "";
            DESCRIPTION = "";
            REFUNDFLAG = "0";
            PAYDATE = "";
            ORDERDATE = "";
            FINALDATE = "";
            FINALUNPAID = "0";
            PAYCALFLAG = "0";
            CRTIME = "";
            CASHRECEIPTID = "0";
            CRISSUED = "0";
            DISCD = "0";
            TAX = "0";
            MODTIME = "";
            CUSTNAME = "";
            CUSTNO = "";
            CONSULTNOTE = "";
            TOTALPRICE = "0";
            ASSESSMENT = "";
        }
    }

    public class SALEITEM
    {
        public string PatientID { get; set; }
        public string MedicalRecordID { get; set; }
    }

    public class CUSTOMERMEMO
    {
        public string ORGID { get; set; }
        public string USERID { get; set; }
        public string EMPLNAME { get; set; }
        public string CUSTOMERID { get; set; }
        public string MEMO { get; set; }
        public string MEMODATE { get; set; }
        public string MEMOTYPE { get; set; }
        public string DISCD { get; set; }
        public string CALLTYPE { get; set; }
        public string CRTIME { get; set; }
        public string SCHEDULEID { get; set; }
        public string TOP { get; set; }
        public string EMPLOYEEID { get; set; }
        public string MODTIME { get; set; }
        public string COLOR { get; set; }
        public string CUSTNAME { get; set; }
        public string CUSTNO { get; set; }

        public CUSTOMERMEMO()
        {
            ORGID = "";
            USERID = "";
            EMPLNAME = "";
            CUSTOMERID = "0";
            MEMO = "";
            MEMODATE = "";
            MEMOTYPE = "0";
            DISCD = "0";
            CALLTYPE = "0";
            CRTIME = "";
            SCHEDULEID = "0";
            TOP = "0";
            EMPLOYEEID = "0";
            MODTIME = "";
            COLOR = "";
            CUSTNAME = "";
            CUSTNO = "";
        }
    }
}