﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Spire.Xls;

namespace HanchartDatabase
{
    class ExcelReader
    {
        private string _orgID;
        private string _filename;
        private DataTable excelDataTable;
        //private int _custcount = 0;
        public ExcelReader(string orgID, string filename, int sheetNum)
        {
            _orgID = orgID;
            _filename = filename;
            Workbook workbook = new Workbook();

            workbook.LoadFromFile(_filename);

            //Initailize worksheet
            Worksheet sheet = workbook.Worksheets[sheetNum];
            excelDataTable = sheet.ExportDataTable();
        }

        public List<CUSTOMERPERSONAL> ReadCustomer(int startRow, int size)
        {
            var customerList = new List<CUSTOMERPERSONAL>();
            int count = 0;

            foreach (DataRow row in excelDataTable.Rows)
            {
                count++;
                if (count < startRow)
                    continue;

                // 이름 최초내원일 기념일 주민번호 휴대전화 주소 이메일 ID/닉네임 직장 고객등급
                // 비고 = 비고1 + 비고2 + 비고3, 차트번호 = 차트번호1 + 차트번호2
                // 차트-기타 주소증

                var cust = new CUSTOMERPERSONAL();
                cust.ORGID = _orgID;

                cust.CUSTNAME = row["이름"].ToString();
                cust.CUSTFSTDATE = row["최초내원일"].ToString().Replace(".", "").Replace("월", "").Replace("일", "").Replace(" ","").Replace("-", "");
                cust.ANNIVERSARY = row["기념일"].ToString().Replace("-", "");
                cust.CUSTJN = row["주민번호"].ToString().Replace("-", "");
                cust.CUSTCELL1 = row["휴대전화1"].ToString().Replace("-", "");
                cust.CUSTCELL2 = row["휴대전화2"].ToString().Replace("-", "");
                cust.CUSTADDR11 = row["주소"].ToString();
                cust.CUSTNICKNAME = row["ID/닉네임"].ToString();
                cust.CUSTEMAIL = row["이메일"].ToString();
                cust.CUSTJOB = row["직장"].ToString();

                var custlevel = row["고객등급"].ToString();
                // if 절로 설정한 고객등급 CONFIG 값으로 바꿔주기.
                if(custlevel == "O" || custlevel == "X")
                {
                    cust.CUSTLVL = "";
                } else if(custlevel.IndexOf("기본교육") > -1)
                {
                    cust.CUSTLVL = "1";
                } else if(custlevel.IndexOf("팅커벨") > -1)
                {
                    cust.CUSTLVL = "2";
                } else if(custlevel.IndexOf("파트라슈") > -1)
                {
                    cust.CUSTLVL = "3";
                }
                    

                cust.CUSTMEMO = row["비고"].ToString();
                // cust.CUSTMEMO = row["비고1"].ToString() + row["비고2"].ToString() + row["비고3"].ToString();

                cust.CUSTNO = row["차트번호"].ToString();
                // cust.CUSTNO = row["차트번호1"].ToString() + cust.CUSTNO = row["차트번호2"].ToString();
                var plan = row["플랜"].ToString();
                if(plan == "초식")
                {
                    cust.CUSTTYPE = "1";
                } else if(plan == "과일홈플랜")
                {
                    cust.CUSTTYPE = "2";
                } else if (plan == "과일스마트플랜")
                {
                    cust.CUSTTYPE = "3";
                }
                var schmemo00 = "";
                schmemo00 += MakeCustomerMemo("위반사항", row["위반사항"].ToString());
                schmemo00 += MakeCustomerMemo("정케어", row["정케어"].ToString());
                schmemo00 += MakeCustomerMemo("정케어 성별", row["정케어 성별"].ToString());
                schmemo00 += MakeCustomerMemo("사체 도착일", row["사체 도착일"].ToString());
                schmemo00 += MakeCustomerMemo("사인", row["사인"].ToString());
                schmemo00 += MakeCustomerMemo("정케어 포인트", row["정케어 포인트"].ToString());
                schmemo00 += MakeCustomerMemo("정케어 NEW성별", row["정케어 NEW성별"].ToString());
                schmemo00 += MakeCustomerMemo("정케어 결제", row["정케어 결제"].ToString());
                var dateinfo = row["정케어 해피콜"].ToString();
                if(dateinfo.IndexOf("월") > -1 && dateinfo.IndexOf("일") > -1)
                {
                    dateinfo = "2018 " + dateinfo.Replace("월", "").Replace("일", "");
                }
                schmemo00 += MakeCustomerMemo("정케어 해피콜", dateinfo);
                dateinfo = row["정케어 분양일"].ToString();
                if (dateinfo.IndexOf("월") > -1 && dateinfo.IndexOf("일") > -1)
                {
                    dateinfo = "2018 " + dateinfo.Replace("월", "").Replace("일", "");
                }
                schmemo00 += MakeCustomerMemo("정케어 분양일", dateinfo);
                schmemo00 += MakeCustomerMemo("정케어 분양방법", row["정케어 분양방법"].ToString());
                schmemo00 += MakeCustomerMemo("정케어 특이사항", row["정케어 특이사항"].ToString());
                cust.SCHMEMO00 = schmemo00;
                //
                var schmemo01 = "";
                schmemo01 += MakeCustomerMemo("루시터 유형", row["루시터 유형"].ToString());
                schmemo01 += MakeCustomerMemo("루시터 성별", row["루시터 성별"].ToString());
                dateinfo = row["루시터 입소일"].ToString();
                if (dateinfo.IndexOf("월") > -1 && dateinfo.IndexOf("일") > -1)
                {
                    dateinfo = "2018 " + dateinfo.Replace("월", "").Replace("일", "");
                }
                schmemo01 += MakeCustomerMemo("루시터 입소일", dateinfo);
                schmemo01 += MakeCustomerMemo("루시터 입소방법", row["루시터 입소방법"].ToString());
                dateinfo = row["루시터 퇴소일"].ToString();
                if (dateinfo.IndexOf("월") > -1 && dateinfo.IndexOf("일") > -1)
                {
                    dateinfo = "2018 " + dateinfo.Replace("월", "").Replace("일", "");
                }
                schmemo01 += MakeCustomerMemo("루시터 퇴소일", dateinfo);
                schmemo01 += MakeCustomerMemo("루시터 퇴소방법", row["루시터 퇴소방법"].ToString());
                schmemo01 += MakeCustomerMemo("루시터 신청서 첨부", row["루시터 신청서 첨부"].ToString());
                schmemo01 += MakeCustomerMemo("루시터 결제금액", row["루시터 결제금액"].ToString());
                schmemo01 += MakeCustomerMemo("루시터 비고", row["루시터 비고"].ToString());
                cust.SCHMEMO01 = schmemo01;
                //
                var schmemo02 = "";
                schmemo02 += MakeCustomerMemo("바이탈 유형", row["바이탈 유형"].ToString());
                schmemo02 += MakeCustomerMemo("바이탈 성별", row["바이탈 성별"].ToString());
                dateinfo = row["바이탈 입소일"].ToString();
                if (dateinfo.IndexOf("월") > -1 && dateinfo.IndexOf("일") > -1)
                {
                    dateinfo = "2018 " + dateinfo.Replace("월", "").Replace("일", "");
                }
                schmemo02 += MakeCustomerMemo("바이탈 입소일", dateinfo);
                schmemo02 += MakeCustomerMemo("바이탈 입소방법", row["바이탈 입소방법"].ToString());
                dateinfo = row["바이탈 퇴소일"].ToString();
                if (dateinfo.IndexOf("월") > -1 && dateinfo.IndexOf("일") > -1)
                {
                    dateinfo = "2018 " + dateinfo.Replace("월", "").Replace("일", "");
                }
                schmemo02 += MakeCustomerMemo("바이탈 퇴소일", dateinfo);
                schmemo02 += MakeCustomerMemo("바이탈 퇴소방법", row["바이탈 퇴소방법"].ToString());
                schmemo02 += MakeCustomerMemo("바이탈 신청서 첨부", row["바이탈 신청서 첨부"].ToString());
                schmemo02 += MakeCustomerMemo("바이탈 결제금액", row["바이탈 결제금액"].ToString());
                schmemo02 += MakeCustomerMemo("바이탈 비고", row["바이탈 비고"].ToString());
                cust.SCHMEMO02 = schmemo02;
                //
                var schmemo40 = "";
                schmemo40 += MakeCustomerMemo("재교육 유형", row["재교육 유형"].ToString());
                schmemo40 += MakeCustomerMemo("재교육 성별", row["재교육 성별"].ToString());
                dateinfo = row["재교육 입소일"].ToString();
                if (dateinfo.IndexOf("월") > -1 && dateinfo.IndexOf("일") > -1)
                {
                    dateinfo = "2018 " + dateinfo.Replace("월", "").Replace("일", "");
                }
                schmemo40 += MakeCustomerMemo("재교육 입소일", dateinfo);
                schmemo40 += MakeCustomerMemo("재교육 입소방법", row["재교육 입소방법"].ToString());
                dateinfo = row["재교육 퇴소일"].ToString();
                if (dateinfo.IndexOf("월") > -1 && dateinfo.IndexOf("일") > -1)
                {
                    dateinfo = "2018 " + dateinfo.Replace("월", "").Replace("일", "");
                }
                schmemo40 += MakeCustomerMemo("재교육 퇴소일", dateinfo);
                schmemo40 += MakeCustomerMemo("재교육 퇴소방법", row["재교육 퇴소방법"].ToString());
                schmemo40 += MakeCustomerMemo("재교육 신청서 첨부", row["재교육 신청서 첨부"].ToString());
                schmemo40 += MakeCustomerMemo("재교육 결제금액", row["재교육 결제금액"].ToString());
                schmemo40 += MakeCustomerMemo("재교육 비고", row["재교육 비고"].ToString());
                cust.SCHMEMO40 = schmemo40;
                //
                var schmemo41 = "";
                dateinfo = row["가족만들기 신청일"].ToString();
                if (dateinfo.IndexOf("월") > -1 && dateinfo.IndexOf("일") > -1)
                {
                    dateinfo = "2018 " + dateinfo.Replace("월", "").Replace("일", "");
                }
                schmemo41 += MakeCustomerMemo("가족만들기 신청일", dateinfo);
                dateinfo = row["가족만들기 게시일"].ToString();
                if (dateinfo.IndexOf("월") > -1 && dateinfo.IndexOf("일") > -1)
                {
                    dateinfo = "2018 " + dateinfo.Replace("월", "").Replace("일", "");
                }
                schmemo41 += MakeCustomerMemo("가족만들기 게시일", dateinfo);
                schmemo41 += MakeCustomerMemo("분양가", row["분양가"].ToString());
                schmemo41 += MakeCustomerMemo("양수인 이름", row["양수인 이름"].ToString());
                schmemo41 += MakeCustomerMemo("양수인 아이디", row["양수인 아이디"].ToString());
                schmemo41 += MakeCustomerMemo("양수인 연락처", row["양수인 연락처"].ToString());
                schmemo41 += MakeCustomerMemo("가족만들기 비고", row["가족만들기 비고"].ToString());
                cust.SCHMEMO41 = schmemo41;
                //
                var schmemo42 = "";
                schmemo42 += MakeCustomerMemo("스쿨 유형", row["스쿨 유형"].ToString());
                schmemo42 += MakeCustomerMemo("스쿨 성별", row["스쿨 성별"].ToString());
                dateinfo = row["스쿨 입소일"].ToString();
                if (dateinfo.IndexOf("월") > -1 && dateinfo.IndexOf("일") > -1)
                {
                    dateinfo = "2018 " + dateinfo.Replace("월", "").Replace("일", "");
                }
                schmemo42 += MakeCustomerMemo("스쿨 입소일", dateinfo);
                schmemo42 += MakeCustomerMemo("스쿨 입소방법", row["스쿨 입소방법"].ToString());
                dateinfo = row["스쿨 퇴소일"].ToString();
                if (dateinfo.IndexOf("월") > -1 && dateinfo.IndexOf("일") > -1)
                {
                    dateinfo = "2018 " + dateinfo.Replace("월", "").Replace("일", "");
                }
                schmemo42 += MakeCustomerMemo("스쿨 퇴소일", dateinfo);
                schmemo42 += MakeCustomerMemo("스쿨 퇴소방법", row["스쿨 퇴소방법"].ToString());
                schmemo42 += MakeCustomerMemo("스쿨 신청서 첨부", row["스쿨 신청서 첨부"].ToString());
                schmemo42 += MakeCustomerMemo("스쿨 결제금액", row["스쿨 결제금액"].ToString());
                schmemo42 += MakeCustomerMemo("스쿨 비고", row["스쿨 비고"].ToString());
                cust.SCHMEMO42 = schmemo42;
                //

                cust.SCHMEMO1 = row["주소증"].ToString();

                cust.SCHMEMO4 = row["차트-기타"].ToString();

                cust.CRTIME = System.DateTime.Now.ToString("yyyyMMddHHmmss");
                customerList.Add(cust);

                if (customerList.Count() == size)
                    break;
            }

            return customerList;
        }

        public string MakeCustomerMemo(string title, string content)
        {
            string Memo = "";
            if(content != "")
            {
                Memo += title + ": " + content + ", ";
            }
            return Memo;
        }
    }
}
