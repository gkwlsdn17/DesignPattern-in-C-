﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace HanchartDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            string dbName = "h00363";
            string orgID = "363";
            string filename = @"C:\Users\Server\Desktop\리본\리본예약리스트.xlsx";
            // var hanaroReader = new ExcelReader(orgID,filename,0);
            var mytproReader = new MytProReader(orgID, filename, 0);
            
            var mysqlWriter = new VegasWriteMysql(dbName);
            mysqlWriter.mtpreader = mytproReader;

            /* 마이티프로 */
            /* 환자정보 입력 시 (폴더번호, 이름, 차트번호를 키값으로 SELECT -> UPDATE / INSERT)  */
            //mysqlWriter.MigrateCustomerMytPro();
            //mysqlWriter.MigrateResvScheduleMytPro();
            //mysqlWriter.MigrateResvScheduleUpdateMytPro();
            //mysqlWriter.MigrateConsultScheduleMytPro();
            //mysqlWriter.MigratePaymentScheduleMytPro();

            /* 하임 크리에이티브 */
            //mysqlWriter.MigrateCustomerPersonal();
        }
    }
}
